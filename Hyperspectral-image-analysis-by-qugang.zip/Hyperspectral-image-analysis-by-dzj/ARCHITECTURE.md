# Unified Hyperspectral Viewer - Architecture Documentation

## Overview

The Unified Hyperspectral Viewer is a comprehensive desktop application designed for interactive analysis of hyperspectral data. It features a single-page interface that integrates image display, spectral analysis, ROI management, and batch processing capabilities.

## System Architecture

### High-Level Architecture

```mermaid
graph TB
    subgraph "Presentation Layer"
        GUI[Graphical User Interface]
        CV[Canvas Visualization]
        PL[Plotting System]
    end
    
    subgraph "Application Layer"
        UV[Unified Viewer Controller]
        EM[Event Manager]
        SM[State Manager]
    end
    
    subgraph "Business Logic Layer"
        DL[Data Loader Service]
        RP[ROI Processor Service]
        FS[File Service]
        EX[Export Service]
    end
    
    subgraph "Data Access Layer"
        FD[File Data Access]
        CD[Configuration Data]
        RD[ROI Data Persistence]
    end
    
    subgraph "Infrastructure Layer"
        LG[Logging System]
        CF[Configuration System]
        ERR[Error Handling]
    end
    
    GUI --> UV
    CV --> UV
    PL --> UV
    
    UV --> DL
    UV --> RP
    UV --> FS
    UV --> EX
    
    DL --> FD
    RP --> FD
    FS --> FD
    EX --> FD
    
    UV --> EM
    UV --> SM
    
    EM --> LG
    SM --> CF
    UV --> ERR
    
    CF --> CD
    EX --> RD
```

## Core Components

### 1. UnifiedHyperspectralViewer Class

**Responsibilities**:
- Main application controller
- UI initialization and management
- Event handling and coordination
- State management

**Key Attributes**:
```python
current_hsi_data: np.ndarray        # Current hyperspectral data cube
current_wavelengths: np.ndarray     # Wavelength array
current_file_path: str              # Path to current file
roi_patches: List[Tuple]           # ROI coordinates (x1, y1, x2, y2)
roi_spectra: List[np.ndarray]      # Extracted spectra for each ROI
roi_colors: List[str]              # Colors for ROI visualization
active_roi_index: Optional[int]    # Currently selected ROI index
roi_labels: List[str]              # User-defined ROI labels
```

### 2. DataLoader Service

**Responsibilities**:
- File format detection and loading
- Byte order handling for ENVI files
- Metadata extraction
- Data validation

**Supported Formats**:
- ENVI (.hdr + data files)
- MATLAB (.mat)
- Raw binary files
- Common image formats

### 3. ROIProcessor Service

**Responsibilities**:
- ROI coordinate management
- Spectral extraction from ROIs
- ROI data validation
- Coordinate transformation

### 4. Export Service

**Responsibilities**:
- Image export (PNG, JPEG, PDF, SVG)
- CSV data export with metadata
- Automatic file naming
- Quality control

## Data Flow

### File Loading Sequence

```mermaid
sequenceDiagram
    participant User
    participant UV as UnifiedViewer
    participant DL as DataLoader
    participant FS as FileSystem
    participant RP as ROIProcessor
    
    User->>UV: Load File
    UV->>DL: load_file(file_path)
    DL->>FS: read_file_metadata()
    FS-->>DL: metadata
    DL->>DL: detect_format()
    DL->>DL: validate_data()
    DL->>FS: read_binary_data()
    FS-->>DL: raw_data
    DL->>DL: convert_to_ndarray()
    DL-->>UV: hsi_data, wavelengths, metadata
    
    UV->>UV: clear_existing_rois()
    UV->>UV: try_auto_load_rois()
    UV->>UV: update_band_controls()
    UV->>UV: update_image_display()
    UV-->>User: Display loaded data
```

### ROI Processing Sequence

```mermaid
sequenceDiagram
    participant User
    participant UV as UnifiedViewer
    participant RP as ROIProcessor
    participant CV as Canvas
    
    User->>CV: Click on image
    CV->>UV: canvas_click_event(x, y)
    UV->>UV: check_existing_rois(x, y)
    alt Click on existing ROI
        UV->>UV: set_active_roi(index)
        UV->>UV: update_roi_display()
        UV-->>User: Highlight selected ROI
    else Create new ROI
        UV->>UV: create_new_roi(x, y)
        UV->>RP: extract_spectrum(coords)
        RP-->>UV: spectrum_data
        UV->>UV: update_roi_data()
        UV->>UV: update_spectrum_display()
        UV->>UV: update_roi_list()
        UV-->>User: Show new ROI and spectrum
    end
```

## UI Architecture

### Layout Structure

```
Main Window
├── Title Bar
├── Top Control Area
│   ├── File Controls (Load, Add Folder)
│   ├── Filter Selection
│   └── Navigation Controls
├── Main Content Area
│   ├── Left Panel (60%)
│   │   └── Image Display & ROI Management
│   │       ├── Matplotlib Canvas
│   │       ├── Navigation Toolbar
│   │       ├── Band Controls
│   │       └── ROI Controls
│   └── Right Panel (40%)
│       ├── Top Right: Spectrum Analysis
│       │   └── Spectrum Plot Canvas
│       └── Bottom Right: Batch Processing
│           ├── File Listbox
│           ├── Batch Controls
│           └── Progress Bar
└── Status Bar
    ├── Status Message
    └── File Info
```

### Event Handling System

```mermaid
graph LR
    subgraph "Event Sources"
        MC[Mouse Clicks]
        KB[Keyboard Input]
        BT[Button Clicks]
        LB[Listbox Selection]
    end
    
    subgraph "Event Handlers"
        EH1[Canvas Click Handler]
        EH2[Key Press Handler]
        EH3[Button Click Handler]
        EH4[Listbox Select Handler]
    end
    
    subgraph "Action Processors"
        AP1[ROI Management]
        AP2[File Operations]
        AP3[Display Updates]
        AP4[Export Operations]
    end
    
    MC --> EH1
    KB --> EH2
    BT --> EH3
    LB --> EH4
    
    EH1 --> AP1
    EH2 --> AP1
    EH3 --> AP2
    EH3 --> AP4
    EH4 --> AP3
```

## Data Persistence

### ROI Auto-save Mechanism

```mermaid
graph TB
    subgraph "Auto-save Trigger"
        T1[Load New File]
        T2[Application Exit]
        T3[Manual Save]
    end
    
    subgraph "Data Collection"
        DC1[Collect ROI Coordinates]
        DC2[Extract Spectra Data]
        DC3[Gather Metadata]
    end
    
    subgraph "CSV Generation"
        CG1[Create DataFrame]
        CG2[Add ROI Index]
        CG3[Add Coordinates]
        CG4[Add Spectral Data]
        CG5[Add Metadata]
    end
    
    subgraph "File Output"
        FO1[Generate Filename]
        FO2[Write CSV File]
        FO3[Error Handling]
    end
    
    T1 --> DC1
    T2 --> DC1
    T3 --> DC1
    
    DC1 --> DC2
    DC2 --> DC3
    
    DC3 --> CG1
    CG1 --> CG2
    CG2 --> CG3
    CG3 --> CG4
    CG4 --> CG5
    
    CG5 --> FO1
    FO1 --> FO2
    FO2 --> FO3
```

### Configuration Management

```python
# Configuration structure
config = {
    "logging": {
        "level": "INFO",
        "file": "hyperspectral_processor.log"
    },
    "processing": {
        "default_filter": "*.hdr",
        "auto_save_rois": True,
        "roi_default_size": 10
    },
    "ui": {
        "window_size": "1600x1000",
        "theme": "default"
    }
}
```

## Error Handling Strategy

### Error Types and Handling

1. **File Loading Errors**:
   - Format detection failures
   - File corruption
   - Missing header files

2. **Processing Errors**:
   - ROI coordinate validation
   - Spectral extraction failures
   - Memory allocation issues

3. **UI Errors**:
   - Canvas rendering issues
   - Event handling conflicts
   - State synchronization problems

4. **Export Errors**:
   - File permission issues
   - Disk space problems
   - Format compatibility issues

### Error Recovery

```mermaid
graph TB
    subgraph "Error Detection"
        ED1[Exception Monitoring]
        ED2[Input Validation]
        ED3[State Validation]
    end
    
    subgraph "Error Handling"
        EH1[User Notification]
        EH2[State Rollback]
        EH3[Resource Cleanup]
    end
    
    subgraph "Recovery Actions"
        RA1[Retry Operation]
        RA2[Skip Problematic Item]
        RA3[Fallback to Defaults]
    end
    
    ED1 --> EH1
    ED2 --> EH2
    ED3 --> EH3
    
    EH1 --> RA1
    EH2 --> RA2
    EH3 --> RA3
```

## Performance Considerations

### Memory Management
- **Lazy Loading**: Only load necessary data portions
- **ROI Data Optimization**: Store only extracted spectra, not full image data
- **Garbage Collection**: Proper cleanup of temporary objects
- **File Streaming**: Process large files in chunks when possible

### UI Responsiveness
- **Asynchronous Operations**: Long-running tasks in background threads
- **Progressive Rendering**: Update displays incrementally
- **Event Debouncing**: Prevent excessive UI updates
- **Caching**: Cache frequently accessed data

## Extension Points

### 1. File Format Support
```python
class CustomDataLoader(DataLoader):
    def load_custom_format(self, file_path):
        # Implement custom format loading
        pass
```

### 2. Analysis Algorithms
```python
class AdvancedAnalyzer:
    def analyze_spectral_features(self, spectra):
        # Add custom analysis algorithms
        pass
```

### 3. Export Formats
```python
class CustomExporter:
    def export_to_custom_format(self, data, file_path):
        # Implement custom export format
        pass
```

### 4. UI Themes
```python
class ThemeManager:
    def apply_dark_theme(self):
        # Implement theme switching
        pass
```

## Testing Strategy

### Unit Tests
- DataLoader format detection
- ROIProcessor coordinate validation
- Export service file generation

### Integration Tests
- File loading and ROI processing pipeline
- UI event handling and state management
- Auto-save/auto-load functionality

### Performance Tests
- Large file loading performance
- Memory usage profiling
- UI responsiveness metrics

## Deployment Considerations

### Dependencies
```yaml
python: ">=3.8"
dependencies:
  - numpy>=1.21.0
  - matplotlib>=3.5.0
  - spectral>=0.22.0
  - pandas>=1.3.0
  - scipy>=1.7.0
  - tkinter  # Built-in
```

### Platform Support
- **Windows**: Full support
- **macOS**: Full support
- **Linux**: Full support

### Distribution Options
- PyPI package
- Standalone executable (PyInstaller)
- Docker container
- Source distribution

## Future Enhancements

### Planned Features
1. **3D Visualization**: Volume rendering of hyperspectral data
2. **Machine Learning Integration**: Automated feature detection
3. **Cloud Integration**: Remote file access and processing
4. **Plugin System**: Extensible architecture for custom algorithms
5. **Multi-language Support**: Internationalization
6. **Advanced Export**: Support for more scientific data formats

### Technical Debt
1. **Refactor UI Components**: Modularize complex UI elements
2. **Improve Error Messages**: More user-friendly error reporting
3. **Optimize Memory Usage**: Better handling of large datasets
4. **Enhanced Testing**: Increase test coverage
5. **Documentation**: Complete API documentation

This architecture provides a solid foundation for a professional hyperspectral analysis tool with excellent extensibility and maintainability characteristics.
