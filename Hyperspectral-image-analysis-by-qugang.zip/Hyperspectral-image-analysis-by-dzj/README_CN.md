# 统一高光谱查看器

一个全面的Python应用程序，用于处理和分析高光谱数据，具有交互式ROI选择、光谱分析和批处理功能，采用统一单页界面设计。

## 功能特性

- **统一界面**: 单页设计，所有功能可见
- **多格式支持**: 加载和处理各种高光谱文件格式（ENVI、MATLAB、原始数据文件）
- **交互式ROI管理**: 图形界面选择和管理的感兴趣区域
- **实时光谱分析**: 多ROI比较的实时光谱可视化
- **批处理**: 文件夹导入和文件过滤的多文件处理
- **增强导出**: 智能默认命名的图像、光谱图和CSV数据保存
- **自动保存/加载**: ROI数据在会话间自动持久化
- **增强可视化**: ROI编号、选择高亮和专业图像输出

## 安装

### 前置要求

- Python 3.8 或更高版本
- pip 包管理器

### 安装依赖

```bash
pip install -r requirements.txt
```

### 运行应用程序

```bash
python run_unified.py
```

## 快速开始

1. **启动应用程序**: 运行 `python run_unified.py`
2. **加载文件**: 点击"Load File"打开高光谱文件
3. **创建ROI**: 在图像上点击创建感兴趣区域
4. **分析光谱**: 在光谱面板查看实时光谱曲线
5. **保存结果**: 使用保存按钮导出图像、图表和数据

## 项目架构

### 系统概览

```mermaid
graph TB
    subgraph "应用层"
        UV[统一查看器]
        CM[配置管理器]
        LG[日志系统]
    end
    
    subgraph "核心处理层"
        DL[数据加载器]
        RP[ROI处理器]
    end
    
    subgraph "UI层"
        MF[主框架]
        IF[图像框架]
        SF[光谱框架]
        BF[批处理框架]
    end
    
    subgraph "外部依赖"
        TK[Tkinter]
        MPL[Matplotlib]
        NP[NumPy]
        SP[Spectral]
        PD[Pandas]
    end
    
    UV --> CM
    UV --> LG
    UV --> DL
    UV --> RP
    UV --> MF
    MF --> IF
    MF --> SF
    MF --> BF
    
    DL --> NP
    DL --> SP
    RP --> NP
    IF --> MPL
    SF --> MPL
    MF --> TK
```

### 类图

```mermaid
classDiagram
    class UnifiedHyperspectralViewer {
        -current_hsi_data: ndarray
        -current_wavelengths: ndarray
        -current_file_path: str
        -roi_patches: list
        -roi_spectra: list
        -roi_colors: list
        -active_roi_index: int
        -roi_labels: list
        +__init__()
        +run()
        -_setup_ui()
        -_setup_event_bindings()
        -_load_file()
        -_add_roi()
        -_delete_roi()
        -_save_image()
        -_save_spectrum_fig()
        -_save_spectra()
    }
    
    class DataLoader {
        +load_file(file_path): tuple
        +check_and_add_byte_order(hdr_path)
    }
    
    class ROIProcessor {
        +extract_spectrum(hsi_data, coords): ndarray
    }
    
    class ConfigManager {
        +load_config()
        +save_config()
    }
    
    UnifiedHyperspectralViewer --> DataLoader
    UnifiedHyperspectralViewer --> ROIProcessor
    UnifiedHyperspectralViewer --> ConfigManager
```

### 时序图: 文件加载和ROI处理

```mermaid
sequenceDiagram
    participant User
    participant Viewer
    participant DataLoader
    participant ROIProcessor
    
    User->>Viewer: 加载文件
    Viewer->>DataLoader: load_file(file_path)
    DataLoader-->>Viewer: hsi_data, wavelengths
    Viewer->>Viewer: 清除现有ROI
    Viewer->>Viewer: 尝试从CSV自动加载ROI
    Viewer-->>User: 显示图像和光谱
    
    User->>Viewer: 点击创建ROI
    Viewer->>ROIProcessor: extract_spectrum(coords)
    ROIProcessor-->>Viewer: spectrum_data
    Viewer->>Viewer: 更新显示
    Viewer-->>User: 显示ROI和光谱
    
    User->>Viewer: 保存结果
    Viewer->>Viewer: 导出数据到CSV/PNG
    Viewer-->>User: 确认消息
```

## 关键组件

### UnifiedHyperspectralViewer (`hyperspectral_processor/unified_viewer.py`)
集成所有功能到单一界面的主应用程序类。

### DataLoader (`hyperspectral_processor/core/data_loader.py`)
处理各种高光谱文件格式的加载和字节序检测。

### ROIProcessor (`hyperspectral_processor/core/roi_processor.py`)
从选定的ROI中提取光谱数据并管理坐标处理。

### ConfigManager (`hyperspectral_processor/config/config_manager.py`)
管理应用程序配置和设置持久化。

## 文件结构

```
hyperspectral_processor/
├── __init__.py                 # 包初始化
├── unified_viewer.py          # 主统一查看器应用程序
├── config/                    # 配置管理
│   ├── __init__.py
│   ├── config_manager.py      # 配置管理器
│   └── settings.py           # 应用程序设置
├── core/                      # 核心处理模块
│   ├── __init__.py
│   ├── data_loader.py        # 数据加载和格式处理
│   └── roi_processor.py      # ROI处理
├── utils/                     # 工具函数
│   ├── __init__.py
│   ├── logger.py             # 日志配置
│   ├── file_utils.py         # 文件操作工具
│   └── validation.py         # 数据验证
└── run_unified.py            # 应用程序入口点
```

## 使用示例

### 基本操作

```python
# 运行统一查看器
from hyperspectral_processor.unified_viewer import main
main()
```

### 编程式ROI处理

```python
from hyperspectral_processor.core.data_loader import DataLoader
from hyperspectral_processor.core.roi_processor import ROIProcessor

# 加载数据
loader = DataLoader()
hsi_data, wavelengths, metadata = loader.load_file("sample.hdr")

# 处理ROI
processor = ROIProcessor()
roi_coords = [(100, 100, 110, 110), (200, 200, 210, 210)]
spectra = [processor.extract_spectrum(hsi_data, coords) for coords in roi_coords]
```

## 支持的文件格式

- **ENVI文件**: `.hdr` 头文件及相关数据文件
- **MATLAB文件**: 包含高光谱数据的 `.mat` 文件
- **原始数据文件**: 具有适当头文件的 `.dat`, `.img`, `.raw`
- **常见图像格式**: 有限的光谱支持

## 配置

应用程序使用 `config.ini` 进行持久化设置：

```ini
[logging]
level = INFO
file = hyperspectral_processor.log

[processing]
default_filter = *.hdr
auto_save_rois = true
```

## 增强功能

### ROI管理
- **编号ROI**: 每个ROI显示其索引号
- **选择高亮**: 活动ROI具有更粗的边框
- **键盘导航**: 使用箭头键移动选定的ROI
- **自动持久化**: ROI随文件自动保存/加载

### 导出能力
- **高质量图像**: 300 DPI PNG/JPEG/PDF/SVG输出
- **智能命名**: 自动文件名生成
- **CSV数据导出**: 包含元数据的全面光谱数据
- **光谱图表**: 专业质量的光谱图表

### 批处理
- **文件夹导入**: 添加具有文件过滤的整个文件夹
- **文件导航**: 上一个/下一个文件导航
- **进度跟踪**: 可视化进度指示器

## 依赖项

- **Python 3.8+**: 核心语言
- **Tkinter**: GUI框架
- **Matplotlib**: 绘图和可视化
- **NumPy**: 数值计算
- **Spectral**: 高光谱数据处理
- **Pandas**: 数据导出和操作
- **SciPy**: 科学计算

## 贡献

1. Fork 仓库
2. 创建特性分支 (`git checkout -b feature/amazing-feature`)
3. 提交更改 (`git commit -m '添加惊人特性'`)
4. 推送到分支 (`git push origin feature/amazing-feature`)
5. 打开拉取请求

## 许可证

本项目采用MIT许可证 - 详见LICENSE文件。

## 支持

有关问题和疑问，请查看文档或在仓库上提出问题。
