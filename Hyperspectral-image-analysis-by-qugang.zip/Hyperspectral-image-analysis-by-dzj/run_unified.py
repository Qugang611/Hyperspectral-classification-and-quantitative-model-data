#!/usr/bin/env python3
"""
Run script for the unified hyperspectral viewer
"""

import sys
import os

# Add the current directory to Python path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

try:
    from hyperspectral_processor.unified_viewer import main
    print("Starting Unified Hyperspectral Viewer...")
    print("=" * 50)
    print("Features:")
    print("- Single page interface with all functionality visible")
    print("- Left: Image display & ROI management")
    print("- Top right: Spectrum analysis")
    print("- Bottom right: Batch processing")
    print("- File extension filtering (default: *.hdr)")
    print("=" * 50)
    main()
except ImportError as e:
    print(f"Import error: {e}")
    print("Please make sure all dependencies are installed:")
    print("pip install -r requirements.txt")
except Exception as e:
    print(f"Error starting application: {e}")
