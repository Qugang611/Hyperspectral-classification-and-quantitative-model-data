"""
File utility functions - File operations and validation
"""

import os
import glob
import re
from pathlib import Path
from typing import List, Tuple, Optional, Generator
import logging

logger = logging.getLogger(__name__)

def validate_file_path(file_path: str, check_exists: bool = True) -> Tuple[bool, str]:
    """
    Validate file path
    
    Args:
        file_path: Path to validate
        check_exists: Whether to check if file exists
        
    Returns:
        Tuple of (is_valid, error_message)
    """
    if not file_path or not isinstance(file_path, str):
        return False, "File path must be a non-empty string"
    
    if len(file_path) > 4096:  # Maximum path length on most systems
        return False, "File path is too long"
    
    # Check for invalid characters
    invalid_chars = '<>:"|?*'
    if any(char in file_path for char in invalid_chars):
        return False, f"File path contains invalid characters: {invalid_chars}"
    
    # Check if path is absolute or relative
    try:
        path_obj = Path(file_path)
        if check_exists and not path_obj.exists():
            return False, "File does not exist"
        
        if check_exists and not path_obj.is_file():
            return False, "Path is not a file"
            
    except (OSError, ValueError) as e:
        return False, f"Invalid file path: {str(e)}"
    
    return True, ""

def create_directory(directory_path: str) -> Tuple[bool, str]:
    """
    Create directory if it doesn't exist
    
    Args:
        directory_path: Path to directory
        
    Returns:
        Tuple of (success, error_message)
    """
    try:
        path_obj = Path(directory_path)
        path_obj.mkdir(parents=True, exist_ok=True)
        return True, ""
    except Exception as e:
        return False, f"Failed to create directory: {str(e)}"

def get_file_list(directory: str, patterns: List[str] = None) -> List[str]:
    """
    Get list of files in directory matching patterns
    
    Args:
        directory: Directory to scan
        patterns: List of file patterns (e.g., ['*.hdr', '*.mat'])
        
    Returns:
        List of file paths
    """
    if patterns is None:
        patterns = ['*.hdr', '*.mat']
    
    files = []
    try:
        for pattern in patterns:
            files.extend(glob.glob(os.path.join(directory, pattern), recursive=False))
        
        # Remove duplicates and sort
        files = sorted(list(set(files)))
        logger.debug(f"Found {len(files)} files in {directory}")
        
    except Exception as e:
        logger.error(f"Error scanning directory {directory}: {e}")
    
    return files

def scan_directory(directory: str, recursive: bool = False) -> Generator[str, None, None]:
    """
    Scan directory for hyperspectral files
    
    Args:
        directory: Directory to scan
        recursive: Whether to scan recursively
        
    Returns:
        Generator yielding file paths
    """
    try:
        if recursive:
            for root, _, files in os.walk(directory):
                for file in files:
                    if is_valid_hyperspectral_file(file):
                        yield os.path.join(root, file)
        else:
            for file in os.listdir(directory):
                file_path = os.path.join(directory, file)
                if os.path.isfile(file_path) and is_valid_hyperspectral_file(file):
                    yield file_path
                    
    except Exception as e:
        logger.error(f"Error scanning directory {directory}: {e}")

def is_valid_hyperspectral_file(filename: str) -> bool:
    """
    Check if file is a valid hyperspectral file
    
    Args:
        filename: File name to check
        
    Returns:
        True if valid hyperspectral file
    """
    hyperspectral_extensions = {'.hdr', '.mat', '.dat', '.img', '.raw'}
    file_ext = os.path.splitext(filename)[1].lower()
    
    # For ENVI files, check if corresponding .hdr or data file exists
    if file_ext == '.hdr':
        return True
    elif file_ext in {'.dat', '.img', '.raw'}:
        # Check if corresponding .hdr file exists
        base_name = os.path.splitext(filename)[0]
        hdr_file = base_name + '.hdr'
        return os.path.exists(hdr_file)
    elif file_ext == '.mat':
        return True
    
    return False

def get_file_info(file_path: str) -> dict:
    """
    Get information about a file
    
    Args:
        file_path: Path to file
        
    Returns:
        Dictionary with file information
    """
    try:
        path_obj = Path(file_path)
        stat = path_obj.stat()
        
        return {
            'name': path_obj.name,
            'stem': path_obj.stem,
            'suffix': path_obj.suffix,
            'parent': str(path_obj.parent),
            'size': stat.st_size,
            'created': stat.st_ctime,
            'modified': stat.st_mtime,
            'is_file': path_obj.is_file(),
            'is_dir': path_obj.is_dir()
        }
    except Exception as e:
        logger.error(f"Error getting file info for {file_path}: {e}")
        return {}

def find_matching_csv_file(hsi_file_path: str) -> Optional[str]:
    """
    Find matching CSV file for a hyperspectral file
    
    Args:
        hsi_file_path: Path to hyperspectral file
        
    Returns:
        Path to matching CSV file if exists, None otherwise
    """
    try:
        base_name = os.path.splitext(hsi_file_path)[0]
        csv_file = base_name + '.csv'
        
        if os.path.exists(csv_file):
            return csv_file
        
        # Also check with _spectra suffix (common convention)
        csv_file_alt = base_name + '_spectra.csv'
        if os.path.exists(csv_file_alt):
            return csv_file_alt
            
        return None
        
    except Exception as e:
        logger.error(f"Error finding matching CSV for {hsi_file_path}: {e}")
        return None

def safe_file_operation(func):
    """
    Decorator for safe file operations with error handling
    
    Args:
        func: Function to decorate
        
    Returns:
        Wrapped function
    """
    def wrapper(*args, **kwargs):
        try:
            return func(*args, **kwargs)
        except FileNotFoundError:
            logger.error("File not found")
            return None
        except PermissionError:
            logger.error("Permission denied")
            return None
        except IOError as e:
            logger.error(f"I/O error: {e}")
            return None
        except Exception as e:
            logger.error(f"Unexpected error: {e}")
            return None
    return wrapper
