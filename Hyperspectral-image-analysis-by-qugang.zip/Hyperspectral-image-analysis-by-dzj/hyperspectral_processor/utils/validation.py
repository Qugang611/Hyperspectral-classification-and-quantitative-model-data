"""
Validation utilities - Data validation and verification functions
"""

import numpy as np
from typing import Tuple, List, Optional
import logging

logger = logging.getLogger(__name__)

def validate_roi_coordinates(
    coordinates: Tuple[int, int, int, int], 
    image_shape: Tuple[int, int, int]
) -> Tuple[bool, str]:
    """
    Validate ROI coordinates against image dimensions
    
    Args:
        coordinates: (x1, y1, x2, y2) tuple
        image_shape: (height, width, bands) tuple
        
    Returns:
        Tuple of (is_valid, error_message)
    """
    if len(coordinates) != 4:
        return False, "ROI coordinates must be a tuple of 4 integers"
    
    x1, y1, x2, y2 = coordinates
    
    # Check if coordinates are integers
    if not all(isinstance(coord, int) for coord in coordinates):
        return False, "All ROI coordinates must be integers"
    
    # Check if coordinates are within valid range
    if x1 < 0 or y1 < 0 or x2 < 0 or y2 < 0:
        return False, "ROI coordinates cannot be negative"
    
    if x1 >= x2 or y1 >= y2:
        return False, "ROI coordinates must form a valid rectangle (x1 < x2, y1 < y2)"
    
    # Check against image dimensions
    height, width, _ = image_shape
    if x2 > width or y2 > height:
        return False, f"ROI coordinates exceed image dimensions ({width}x{height})"
    
    # Check minimum size (at least 3x3 pixels)
    if (x2 - x1) < 3 or (y2 - y1) < 3:
        return False, "ROI must be at least 3x3 pixels"
    
    return True, ""

def validate_spectral_data(
    spectral_data: np.ndarray, 
    expected_bands: Optional[int] = None
) -> Tuple[bool, str]:
    """
    Validate spectral data array
    
    Args:
        spectral_data: Numpy array of spectral data
        expected_bands: Expected number of spectral bands
        
    Returns:
        Tuple of (is_valid, error_message)
    """
    if not isinstance(spectral_data, np.ndarray):
        return False, "Spectral data must be a numpy array"
    
    if spectral_data.ndim != 1:
        return False, "Spectral data must be a 1D array"
    
    if len(spectral_data) == 0:
        return False, "Spectral data cannot be empty"
    
    if expected_bands is not None and len(spectral_data) != expected_bands:
        return False, f"Expected {expected_bands} bands, got {len(spectral_data)}"
    
    # Check for NaN or infinite values
    if np.any(np.isnan(spectral_data)):
        return False, "Spectral data contains NaN values"
    
    if np.any(np.isinf(spectral_data)):
        return False, "Spectral data contains infinite values"
    
    return True, ""

def validate_wavelengths(
    wavelengths: np.ndarray, 
    expected_length: Optional[int] = None
) -> Tuple[bool, str]:
    """
    Validate wavelength array
    
    Args:
        wavelengths: Numpy array of wavelengths
        expected_length: Expected number of wavelengths
        
    Returns:
        Tuple of (is_valid, error_message)
    """
    if not isinstance(wavelengths, np.ndarray):
        return False, "Wavelengths must be a numpy array"
    
    if wavelengths.ndim != 1:
        return False, "Wavelengths must be a 1D array"
    
    if len(wavelengths) == 0:
        return False, "Wavelengths cannot be empty"
    
    if expected_length is not None and len(wavelengths) != expected_length:
        return False, f"Expected {expected_length} wavelengths, got {len(wavelengths)}"
    
    # Check if wavelengths are monotonically increasing
    if not np.all(np.diff(wavelengths) > 0):
        return False, "Wavelengths must be strictly increasing"
    
    # Check for valid wavelength range (typical hyperspectral range)
    if np.any(wavelengths < 300) or np.any(wavelengths > 2500):
        logger.warning("Wavelengths outside typical hyperspectral range (300-2500 nm)")
    
    return True, ""

def validate_hyperspectral_data(
    data: np.ndarray, 
    wavelengths: Optional[np.ndarray] = None
) -> Tuple[bool, str]:
    """
    Validate hyperspectral data cube
    
    Args:
        data: 3D numpy array (height, width, bands)
        wavelengths: Optional wavelength array
        
    Returns:
        Tuple of (is_valid, error_message)
    """
    if not isinstance(data, np.ndarray):
        return False, "Data must be a numpy array"
    
    if data.ndim != 3:
        return False, "Hyperspectral data must be 3D (height, width, bands)"
    
    if data.shape[0] == 0 or data.shape[1] == 0 or data.shape[2] == 0:
        return False, "Data dimensions cannot be zero"
    
    # Check for NaN or infinite values
    if np.any(np.isnan(data)):
        return False, "Data contains NaN values"
    
    if np.any(np.isinf(data)):
        return False, "Data contains infinite values"
    
    # Validate wavelengths if provided
    if wavelengths is not None:
        is_valid, message = validate_wavelengths(wavelengths, data.shape[2])
        if not is_valid:
            return False, f"Wavelength validation failed: {message}"
    
    return True, ""

def validate_csv_data(
    data: List[dict], 
    required_columns: List[str] = None
) -> Tuple[bool, str]:
    """
    Validate CSV data structure
    
    Args:
        data: List of dictionaries representing CSV rows
        required_columns: List of required column names
        
    Returns:
        Tuple of (is_valid, error_message)
    """
    if not isinstance(data, list):
        return False, "Data must be a list of dictionaries"
    
    if len(data) == 0:
        return False, "Data cannot be empty"
    
    if required_columns is None:
        required_columns = ['wavelength', 'reflectance']
    
    # Check each row
    for i, row in enumerate(data):
        if not isinstance(row, dict):
            return False, f"Row {i} must be a dictionary"
        
        # Check required columns
        for col in required_columns:
            if col not in row:
                return False, f"Row {i} missing required column: {col}"
    
    return True, ""

def is_numeric(value) -> bool:
    """
    Check if value is numeric
    
    Args:
        value: Value to check
        
    Returns:
        True if numeric
    """
    try:
        float(value)
        return True
    except (ValueError, TypeError):
        return False

def sanitize_filename(filename: str) -> str:
    """
    Sanitize filename by removing invalid characters
    
    Args:
        filename: Original filename
        
    Returns:
        Sanitized filename
    """
    # Remove invalid characters
    invalid_chars = '<>:"/\\|?*'
    for char in invalid_chars:
        filename = filename.replace(char, '_')
    
    # Remove leading/trailing spaces and dots
    filename = filename.strip().strip('.')
    
    # Ensure filename is not empty
    if not filename:
        filename = 'unnamed_file'
    
    return filename

def validate_config_value(section: str, key: str, value: str) -> Tuple[bool, str]:
    """
    Validate configuration value
    
    Args:
        section: Configuration section
        key: Configuration key
        value: Configuration value
        
    Returns:
        Tuple of (is_valid, error_message)
    """
    # Add specific validation rules here based on section and key
    if section == 'UI' and key in ['window_width', 'window_height']:
        if not value.isdigit() or not (100 <= int(value) <= 3840):
            return False, f"{key} must be between 100 and 3840"
    
    elif section == 'Logging' and key == 'log_level':
        valid_levels = ['DEBUG', 'INFO', 'WARNING', 'ERROR', 'CRITICAL']
        if value not in valid_levels:
            return False, f"log_level must be one of {valid_levels}"
    
    return True, ""
