"""
Logging utilities - Configure and manage application logging
"""

import logging
import logging.handlers
import os
from pathlib import Path
from typing import Optional

from ..config.config_manager import ConfigManager

def setup_logger(config: Optional[ConfigManager] = None) -> logging.Logger:
    """
    Set up and configure application logger
    
    Args:
        config: Configuration manager instance
        
    Returns:
        Configured logger instance
    """
    if config is None:
        config = ConfigManager()
    
    # Get logging configuration
    log_level = config.get('Logging', 'log_level', 'INFO')
    log_file = config.get('Logging', 'log_file', 'hyperspectral_processor.log')
    max_log_size = config.get('Logging', 'max_log_size', '10MB')
    backup_count = config.get('Logging', 'backup_count', 5)
    enable_console = config.get('Logging', 'enable_console_log', True)
    
    # Create logger
    logger = logging.getLogger('hyperspectral_processor')
    logger.setLevel(getattr(logging, log_level.upper(), logging.INFO))
    
    # Clear existing handlers
    logger.handlers.clear()
    
    # Create formatter
    formatter = logging.Formatter(
        '%(asctime)s - %(name)s - %(levelname)s - %(message)s',
        datefmt='%Y-%m-%d %H:%M:%S'
    )
    
    # File handler with rotation
    try:
        # Convert max_log_size to bytes (e.g., '10MB' -> 10 * 1024 * 1024)
        if max_log_size.endswith('MB'):
            max_bytes = int(max_log_size[:-2]) * 1024 * 1024
        elif max_log_size.endswith('KB'):
            max_bytes = int(max_log_size[:-2]) * 1024
        else:
            max_bytes = 10 * 1024 * 1024  # Default 10MB
        
        file_handler = logging.handlers.RotatingFileHandler(
            filename=log_file,
            maxBytes=max_bytes,
            backupCount=backup_count,
            encoding='utf-8'
        )
        file_handler.setFormatter(formatter)
        logger.addHandler(file_handler)
    except Exception as e:
        print(f"Failed to setup file logging: {e}")
    
    # Console handler
    if enable_console:
        console_handler = logging.StreamHandler()
        console_handler.setFormatter(formatter)
        logger.addHandler(console_handler)
    
    # Add exception hook for unhandled exceptions
    def handle_exception(exc_type, exc_value, exc_traceback):
        if issubclass(exc_type, KeyboardInterrupt):
            # Don't log keyboard interrupts
            sys.__excepthook__(exc_type, exc_value, exc_traceback)
            return
        
        logger.critical("Unhandled exception", exc_info=(exc_type, exc_value, exc_traceback))
    
    import sys
    sys.excepthook = handle_exception
    
    logger.info("Logger configured successfully")
    logger.info(f"Log level: {log_level}")
    logger.info(f"Log file: {log_file}")
    
    return logger

def get_logger(name: str = 'hyperspectral_processor') -> logging.Logger:
    """
    Get a logger instance with the given name
    
    Args:
        name: Logger name
        
    Returns:
        Logger instance
    """
    return logging.getLogger(name)

class LoggingMixin:
    """Mixin class to add logging capabilities to other classes"""
    
    def __init__(self):
        self._logger = None
    
    @property
    def logger(self) -> logging.Logger:
        """Get logger instance for this class"""
        if self._logger is None:
            self._logger = get_logger(self.__class__.__name__)
        return self._logger
    
    def log_debug(self, message: str, *args, **kwargs) -> None:
        """Log debug message"""
        self.logger.debug(message, *args, **kwargs)
    
    def log_info(self, message: str, *args, **kwargs) -> None:
        """Log info message"""
        self.logger.info(message, *args, **kwargs)
    
    def log_warning(self, message: str, *args, **kwargs) -> None:
        """Log warning message"""
        self.logger.warning(message, *args, **kwargs)
    
    def log_error(self, message: str, *args, **kwargs) -> None:
        """Log error message"""
        self.logger.error(message, *args, **kwargs)
    
    def log_critical(self, message: str, *args, **kwargs) -> None:
        """Log critical message"""
        self.logger.critical(message, *args, **kwargs)
    
    def log_exception(self, message: str, *args, **kwargs) -> None:
        """Log exception with stack trace"""
        self.logger.exception(message, *args, **kwargs)
