"""
Default Configuration Settings - Define default configuration values for the application
"""

import os
from datetime import datetime

# Default configuration dictionary
DEFAULT_CONFIG = {
    'General': {
        'default_data_dir': './data',
        'language': 'en_US',
        'theme': 'dark',
        'auto_update_check': 'true'
    },
    'BatchProcessing': {
        'auto_save': 'true',
        'overwrite_existing': 'false',
        'default_label_source': 'filename',
        'default_name_source': 'directory',
        'max_concurrent_files': '1'
    },
    'Logging': {
        'log_level': 'INFO',
        'log_file': 'hyperspectral_processor.log',
        'max_log_size': '10MB',
        'backup_count': '5',
        'enable_console_log': 'true'
    },
    'CSV': {
        'include_timestamp': 'true',
        'include_coordinates': 'true',
        'compression': 'none',
        'encoding': 'utf-8',
        'delimiter': ',',
        'quote_char': '"'
    },
    'UI': {
        'window_width': '1200',
        'window_height': '800',
        'font_size': '10',
        'show_grid': 'true',
        'auto_scale': 'true'
    },
    'ROI': {
        'default_roi_size': '3',
        'min_roi_size': '3',
        'max_roi_size': '50',
        'auto_extract_spectrum': 'true'
    }
}

# Configuration validation rules
CONFIG_VALIDATION_RULES = {
    'General': {
        'default_data_dir': lambda x: os.path.isabs(x) or x.startswith('./') or x.startswith('../'),
        'language': lambda x: x in ['en_US', 'zh_CN'],
        'theme': lambda x: x in ['dark', 'light', 'system']
    },
    'BatchProcessing': {
        'auto_save': lambda x: x.lower() in ['true', 'false'],
        'overwrite_existing': lambda x: x.lower() in ['true', 'false'],
        'max_concurrent_files': lambda x: x.isdigit() and 1 <= int(x) <= 10
    },
    'Logging': {
        'log_level': lambda x: x in ['DEBUG', 'INFO', 'WARNING', 'ERROR', 'CRITICAL'],
        'max_log_size': lambda x: x.endswith('MB') and x[:-2].isdigit() and int(x[:-2]) > 0
    },
    'UI': {
        'window_width': lambda x: x.isdigit() and 800 <= int(x) <= 3840,
        'window_height': lambda x: x.isdigit() and 600 <= int(x) <= 2160
    }
}

# Configuration type conversions
CONFIG_TYPE_CONVERSIONS = {
    'General': {
        'auto_update_check': bool
    },
    'BatchProcessing': {
        'auto_save': bool,
        'overwrite_existing': bool,
        'max_concurrent_files': int
    },
    'Logging': {
        'backup_count': int,
        'enable_console_log': bool
    },
    'UI': {
        'window_width': int,
        'window_height': int,
        'font_size': int,
        'show_grid': bool,
        'auto_scale': bool
    },
    'ROI': {
        'default_roi_size': int,
        'min_roi_size': int,
        'max_roi_size': int,
        'auto_extract_spectrum': bool
    }
}
