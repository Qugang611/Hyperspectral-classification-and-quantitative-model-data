"""
Configuration Manager - Handles loading, saving, and validation of application configuration
"""

import os
import configparser
from pathlib import Path
from typing import Dict, Any, Optional
import logging

from .settings import DEFAULT_CONFIG, CONFIG_VALIDATION_RULES, CONFIG_TYPE_CONVERSIONS

class ConfigManager:
    """Manages application configuration using INI files"""
    
    def __init__(self, config_file: str = 'config.ini'):
        """
        Initialize configuration manager
        
        Args:
            config_file: Path to configuration file
        """
        self.config_file = config_file
        self.config = configparser.ConfigParser()
        self.logger = logging.getLogger(__name__)
        self._load_config()
    
    def _load_config(self) -> None:
        """Load configuration from file or create default if not exists"""
        if os.path.exists(self.config_file):
            try:
                self.config.read(self.config_file, encoding='utf-8')
                self._validate_config()
                self.logger.info(f"Configuration loaded from {self.config_file}")
            except Exception as e:
                self.logger.error(f"Error loading configuration: {e}")
                self._create_default_config()
        else:
            self._create_default_config()
    
    def _create_default_config(self) -> None:
        """Create default configuration file"""
        try:
            # Create directory if it doesn't exist
            config_dir = os.path.dirname(self.config_file)
            if config_dir and not os.path.exists(config_dir):
                os.makedirs(config_dir)
            
            # Set default values
            for section, options in DEFAULT_CONFIG.items():
                if section not in self.config:
                    self.config[section] = {}
                for key, value in options.items():
                    self.config[section][key] = value
            
            self._save_config()
            self.logger.info(f"Default configuration created at {self.config_file}")
        except Exception as e:
            self.logger.error(f"Error creating default configuration: {e}")
    
    def _validate_config(self) -> None:
        """Validate loaded configuration against rules"""
        for section in self.config.sections():
            if section in CONFIG_VALIDATION_RULES:
                for key in self.config[section]:
                    if key in CONFIG_VALIDATION_RULES[section]:
                        validator = CONFIG_VALIDATION_RULES[section][key]
                        value = self.config[section][key]
                        if not validator(value):
                            self.logger.warning(f"Invalid value '{value}' for {section}.{key}, using default")
                            self.config[section][key] = DEFAULT_CONFIG[section][key]
    
    def _save_config(self) -> None:
        """Save configuration to file"""
        try:
            with open(self.config_file, 'w', encoding='utf-8') as configfile:
                self.config.write(configfile)
            self.logger.debug(f"Configuration saved to {self.config_file}")
        except Exception as e:
            self.logger.error(f"Error saving configuration: {e}")
    
    def get(self, section: str, key: str, default: Any = None) -> Any:
        """
        Get configuration value with type conversion
        
        Args:
            section: Configuration section
            key: Configuration key
            default: Default value if not found
            
        Returns:
            Configuration value with appropriate type
        """
        try:
            if not self.config.has_section(section) or not self.config.has_option(section, key):
                if default is not None:
                    return default
                return DEFAULT_CONFIG.get(section, {}).get(key, None)
            
            value = self.config[section][key]
            
            # Apply type conversion if defined
            if (section in CONFIG_TYPE_CONVERSIONS and 
                key in CONFIG_TYPE_CONVERSIONS[section]):
                converter = CONFIG_TYPE_CONVERSIONS[section][key]
                try:
                    if converter == bool:
                        return value.lower() == 'true'
                    return converter(value)
                except (ValueError, TypeError):
                    self.logger.warning(f"Failed to convert {section}.{key}={value}")
                    return default if default is not None else value
            
            return value
            
        except Exception as e:
            self.logger.error(f"Error getting configuration {section}.{key}: {e}")
            return default if default is not None else None
    
    def set(self, section: str, key: str, value: Any) -> bool:
        """
        Set configuration value
        
        Args:
            section: Configuration section
            key: Configuration key
            value: Configuration value
            
        Returns:
            True if successful, False otherwise
        """
        try:
            if section not in self.config:
                self.config[section] = {}
            
            # Convert value to string for storage
            if isinstance(value, bool):
                value_str = 'true' if value else 'false'
            else:
                value_str = str(value)
            
            self.config[section][key] = value_str
            self._save_config()
            self.logger.debug(f"Configuration updated: {section}.{key} = {value_str}")
            return True
            
        except Exception as e:
            self.logger.error(f"Error setting configuration {section}.{key}: {e}")
            return False
    
    def get_section(self, section: str) -> Dict[str, Any]:
        """
        Get all configuration values from a section
        
        Args:
            section: Configuration section
            
        Returns:
            Dictionary of configuration values
        """
        result = {}
        if self.config.has_section(section):
            for key in self.config[section]:
                result[key] = self.get(section, key)
        return result
    
    def reload(self) -> None:
        """Reload configuration from file"""
        self._load_config()
    
    def reset_to_defaults(self) -> None:
        """Reset configuration to default values"""
        self._create_default_config()
    
    def __getitem__(self, key: str) -> Any:
        """Get configuration value using dot notation (section.key)"""
        if '.' in key:
            section, option = key.split('.', 1)
            return self.get(section, option)
        raise KeyError(f"Configuration key must be in format 'section.key', got: {key}")
    
    def __setitem__(self, key: str, value: Any) -> None:
        """Set configuration value using dot notation (section.key)"""
        if '.' in key:
            section, option = key.split('.', 1)
            self.set(section, option, value)
        else:
            raise KeyError(f"Configuration key must be in format 'section.key', got: {key}")
