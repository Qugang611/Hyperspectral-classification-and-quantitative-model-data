"""
配置管理模块 - 处理应用程序配置的加载、保存和验证
"""

from .config_manager import ConfigManager
from .settings import DEFAULT_CONFIG

__all__ = ['ConfigManager', 'DEFAULT_CONFIG']
