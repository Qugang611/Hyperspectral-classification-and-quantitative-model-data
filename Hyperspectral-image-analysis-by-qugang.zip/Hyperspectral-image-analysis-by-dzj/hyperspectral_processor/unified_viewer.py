"""
Unified Hyperspectral Viewer - Single page application with all features in functional areas
Combines image display, spectrum viewing, ROI selection, and batch processing in one view
"""

import tkinter as tk
from tkinter import ttk, filedialog, messagebox
import matplotlib.pyplot as plt
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg, NavigationToolbar2Tk
from matplotlib.figure import Figure
from matplotlib.patches import Rectangle
import matplotlib.colors as mcolors
import numpy as np
from scipy.io import loadmat
import spectral as spy
import os
import logging
from datetime import datetime
import pandas as pd
import glob

from .utils.logger import setup_logger
from .core.data_loader import DataLoader, check_and_add_byte_order
from .core.roi_processor import ROIProcessor
from .config.config_manager import ConfigManager

logger = logging.getLogger(__name__)

class UnifiedHyperspectralViewer:
    """Unified viewer with all features in a single page layout"""
    
    def __init__(self):
        """Initialize the unified viewer"""
        setup_logger()
        
        self.root = tk.Tk()
        self.root.title("Unified Hyperspectral Viewer")
        self.root.geometry("1600x1000")
        
        self.config_manager = ConfigManager()
        self.data_loader = DataLoader()
        self.roi_processor = ROIProcessor()
        
        # Data storage
        self.current_hsi_data = None
        self.current_wavelengths = None
        self.current_file_path = None
        self.file_list = []
        self.current_file_index = -1
        
        # ROI management
        self.roi_patches = []  # List of ROI coordinates (x1, y1, x2, y2)
        self.roi_spectra = []  # List of spectra for each ROI
        self.roi_colors = []   # List of colors for each ROI
        self.active_roi_index = None
        self.roi_labels = []   # List of ROI labels
        
        # UI setup
        self._setup_ui()
        
        # Event bindings
        self._setup_event_bindings()
    
    def _setup_ui(self):
        """Setup the unified user interface"""
        # Main container with padding
        main_container = ttk.Frame(self.root, padding="10")
        main_container.pack(fill=tk.BOTH, expand=True)
        
        # Title
        title_label = ttk.Label(main_container, text="Unified Hyperspectral Viewer", 
                               font=("Arial", 16, "bold"))
        title_label.pack(pady=10)
        
        # Top control area
        self._setup_top_controls(main_container)
        
        # Main content area (split into left and right)
        content_frame = ttk.Frame(main_container)
        content_frame.pack(fill=tk.BOTH, expand=True, pady=10)
        
        # Left area (60%) - Image display
        left_frame = ttk.LabelFrame(content_frame, text="Image Display & ROI Management", padding="5")
        left_frame.pack(side=tk.LEFT, fill=tk.BOTH, expand=True, padx=(0, 5))
        
        # Right area (40%) - Split into spectrum and batch
        right_frame = ttk.Frame(content_frame)
        right_frame.pack(side=tk.RIGHT, fill=tk.BOTH, expand=True, padx=(5, 0))
        
        # Top right - Spectrum analysis
        spectrum_frame = ttk.LabelFrame(right_frame, text="Spectrum Analysis", padding="5")
        spectrum_frame.pack(fill=tk.BOTH, expand=True, pady=(0, 5))
        
        # Bottom right - Batch processing
        batch_frame = ttk.LabelFrame(right_frame, text="Batch Processing", padding="5")
        batch_frame.pack(fill=tk.BOTH, expand=True, pady=(5, 0))
        
        # Setup each area
        self._setup_image_area(left_frame)
        self._setup_spectrum_area(spectrum_frame)
        self._setup_batch_area(batch_frame)
        
        # Status bar
        self.status_frame = ttk.Frame(main_container)
        self.status_frame.pack(fill=tk.X, pady=5)
        
        self.status_var = tk.StringVar(value="Ready")
        status_label = ttk.Label(self.status_frame, textvariable=self.status_var)
        status_label.pack(side=tk.LEFT)
        
        # File list info
        self.file_info_var = tk.StringVar(value="No files loaded")
        file_info_label = ttk.Label(self.status_frame, textvariable=self.file_info_var)
        file_info_label.pack(side=tk.RIGHT)
    
    def _setup_top_controls(self, parent):
        """Setup top control area"""
        top_frame = ttk.Frame(parent)
        top_frame.pack(fill=tk.X, pady=5)
        
        # File controls
        file_control_frame = ttk.LabelFrame(top_frame, text="File Controls", padding="5")
        file_control_frame.pack(side=tk.LEFT, fill=tk.X, expand=True, padx=(0, 5))
        
        ttk.Button(file_control_frame, text="Load File", command=self._load_single_file).pack(side=tk.LEFT, padx=2)
        ttk.Button(file_control_frame, text="Add Folder", command=self._add_folder).pack(side=tk.LEFT, padx=2)
        
        # File filter
        filter_frame = ttk.Frame(file_control_frame)
        filter_frame.pack(side=tk.LEFT, padx=10)
        
        ttk.Label(filter_frame, text="Filter:").pack(side=tk.LEFT)
        self.filter_var = tk.StringVar(value="*.hdr")
        filter_combo = ttk.Combobox(filter_frame, textvariable=self.filter_var, 
                                   values=["*.hdr", "*.mat", "*.dat", "*.img", "*.raw", "*.*"],
                                   width=10, state="readonly")
        filter_combo.pack(side=tk.LEFT, padx=5)
        
        # File navigation
        nav_frame = ttk.LabelFrame(top_frame, text="Navigation", padding="5")
        nav_frame.pack(side=tk.RIGHT, padx=(5, 0))
        
        ttk.Button(nav_frame, text="← Previous", command=self._prev_file).pack(side=tk.LEFT, padx=2)
        ttk.Button(nav_frame, text="Next →", command=self._next_file).pack(side=tk.LEFT, padx=2)
        ttk.Label(nav_frame, text="File:").pack(side=tk.LEFT, padx=(10, 2))
        
        self.file_nav_var = tk.StringVar(value="0/0")
        ttk.Label(nav_frame, textvariable=self.file_nav_var).pack(side=tk.LEFT)
    
    def _setup_image_area(self, parent):
        """Setup image display area"""
        # Create matplotlib figure for image and spectrum
        self.fig = Figure(figsize=(10, 8))
        self.ax_img = self.fig.add_subplot(111)
        
        # Create canvas
        self.canvas = FigureCanvasTkAgg(self.fig, parent)
        self.canvas.draw()
        
        # Create toolbar
        toolbar_frame = ttk.Frame(parent)
        toolbar_frame.pack(fill=tk.X, pady=(0, 5))
        
        self.toolbar = NavigationToolbar2Tk(self.canvas, toolbar_frame)
        self.toolbar.update()
        
        # Pack canvas
        self.canvas.get_tk_widget().pack(fill=tk.BOTH, expand=True)
        
        # Band controls
        band_frame = ttk.Frame(parent)
        band_frame.pack(fill=tk.X, pady=5)
        
        ttk.Label(band_frame, text="Band:").pack(side=tk.LEFT, padx=5)
        self.band_var = tk.IntVar(value=0)
        self.band_spinbox = ttk.Spinbox(band_frame, from_=0, to=0, 
                                       textvariable=self.band_var, width=5,
                                       command=self._update_band_display)
        self.band_spinbox.pack(side=tk.LEFT, padx=5)
        
        self.band_scale = ttk.Scale(band_frame, from_=0, to=0, 
                                   orient=tk.HORIZONTAL, command=self._on_band_slider)
        self.band_scale.pack(side=tk.LEFT, fill=tk.X, expand=True, padx=10)
        
        # ROI controls
        roi_control_frame = ttk.Frame(parent)
        roi_control_frame.pack(fill=tk.X, pady=5)
        
        ttk.Button(roi_control_frame, text="Add ROI", command=self._add_roi).pack(side=tk.LEFT, padx=2)
        ttk.Button(roi_control_frame, text="Delete ROI", command=self._delete_roi).pack(side=tk.LEFT, padx=2)
        ttk.Button(roi_control_frame, text="Clear All ROIs", command=self._clear_rois).pack(side=tk.LEFT, padx=2)
        ttk.Button(roi_control_frame, text="Save Spectra", command=self._save_spectra).pack(side=tk.LEFT, padx=2)
        ttk.Button(roi_control_frame, text="Save Image", command=self._save_image).pack(side=tk.LEFT, padx=2)
        ttk.Button(roi_control_frame, text="Save Spectrum", command=self._save_spectrum_fig).pack(side=tk.LEFT, padx=2)
    
    def _setup_spectrum_area(self, parent):
        """Setup spectrum analysis area"""
        # Spectrum figure
        self.spectrum_fig = Figure(figsize=(8, 4))
        self.spectrum_ax = self.spectrum_fig.add_subplot(111)
        
        # Spectrum canvas
        self.spectrum_canvas = FigureCanvasTkAgg(self.spectrum_fig, parent)
        self.spectrum_canvas.draw()
        self.spectrum_canvas.get_tk_widget().pack(fill=tk.BOTH, expand=True, pady=5)
        
        # ROI list and controls
        roi_frame = ttk.Frame(parent)
        roi_frame.pack(fill=tk.X, pady=5)
        
        # ROI listbox
        list_frame = ttk.Frame(roi_frame)
        list_frame.pack(fill=tk.BOTH, expand=True, padx=5)
        
        ttk.Label(list_frame, text="ROI List:").pack(anchor=tk.W)
        self.roi_listbox = tk.Listbox(list_frame, height=6)
        roi_scroll = ttk.Scrollbar(list_frame, orient=tk.VERTICAL, command=self.roi_listbox.yview)
        self.roi_listbox.configure(yscrollcommand=roi_scroll.set)
        
        self.roi_listbox.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        roi_scroll.pack(side=tk.RIGHT, fill=tk.Y)
        
        # ROI label controls
        label_frame = ttk.Frame(roi_frame)
        label_frame.pack(fill=tk.X, padx=5, pady=5)
        
        ttk.Label(label_frame, text="Label:").pack(side=tk.LEFT)
        self.roi_label_var = tk.StringVar()
        self.roi_label_entry = ttk.Entry(label_frame, textvariable=self.roi_label_var, width=15)
        self.roi_label_entry.pack(side=tk.LEFT, padx=5)
        ttk.Button(label_frame, text="Update", command=self._update_roi_label).pack(side=tk.LEFT)
    
    def _setup_batch_area(self, parent):
        """Setup batch processing area"""
        # File list
        list_frame = ttk.Frame(parent)
        list_frame.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)
        
        ttk.Label(list_frame, text="File List:").pack(anchor=tk.W)
        self.file_listbox = tk.Listbox(list_frame, height=8)
        file_scroll = ttk.Scrollbar(list_frame, orient=tk.VERTICAL, command=self.file_listbox.yview)
        self.file_listbox.configure(yscrollcommand=file_scroll.set)
        
        self.file_listbox.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        file_scroll.pack(side=tk.RIGHT, fill=tk.Y)
        
        # Batch controls
        control_frame = ttk.Frame(parent)
        control_frame.pack(fill=tk.X, padx=5, pady=5)
        
        ttk.Button(control_frame, text="Add Files", command=self._add_files).pack(side=tk.LEFT, padx=2)
        ttk.Button(control_frame, text="Clear List", command=self._clear_file_list).pack(side=tk.LEFT, padx=2)
        ttk.Button(control_frame, text="Process Selected", command=self._process_selected).pack(side=tk.LEFT, padx=2)
        ttk.Button(control_frame, text="Process All", command=self._process_all).pack(side=tk.LEFT, padx=2)
        
        # Progress bar
        self.progress_var = tk.DoubleVar()
        self.progress_bar = ttk.Progressbar(control_frame, variable=self.progress_var, maximum=100)
        self.progress_bar.pack(side=tk.LEFT, fill=tk.X, expand=True, padx=10)
    
    def _setup_event_bindings(self):
        """Setup event bindings"""
        # Canvas events
        self.canvas.mpl_connect('button_press_event', self._on_canvas_click)
        self.canvas.mpl_connect('key_press_event', self._on_key_press)
        
        # File list events
        self.file_listbox.bind('<<ListboxSelect>>', self._on_file_select)
        self.roi_listbox.bind('<<ListboxSelect>>', self._on_roi_select)
    
    def _on_canvas_click(self, event):
        """Handle canvas click events"""
        if event.inaxes != self.ax_img or self.current_hsi_data is None:
            return
        
        # Get click position
        x, y = int(event.xdata), int(event.ydata)
        
        # Check if clicking on existing ROI
        for i, (x1, y1, x2, y2) in enumerate(self.roi_patches):
            if x1 <= x <= x2 and y1 <= y <= y2:
                self.active_roi_index = i
                self._update_roi_display()
                self.canvas.draw()
                return
        
        # Create new ROI
        size = 10  # Default ROI size
        x1 = max(0, x - size)
        y1 = max(0, y - size)
        x2 = min(self.current_hsi_data.shape[1], x + size)
        y2 = min(self.current_hsi_data.shape[0], y + size)
        
        # Add new ROI
        color = list(mcolors.TABLEAU_COLORS.values())[len(self.roi_patches) % len(mcolors.TABLEAU_COLORS)]
        self.roi_patches.append((x1, y1, x2, y2))
        self.roi_colors.append(color)
        self.roi_spectra.append(None)
        self.roi_labels.append(f"ROI {len(self.roi_patches)}")
        self.active_roi_index = len(self.roi_patches) - 1
        
        # Extract spectrum
        self._extract_spectrum(self.active_roi_index)
        
        # Update displays
        self._update_roi_display()
        self._update_spectrum_display()
        self._update_roi_list()
        
        self.canvas.draw()
    
    def _on_key_press(self, event):
        """Handle keyboard events"""
        if self.active_roi_index is None or self.current_hsi_data is None:
            return
        
        x1, y1, x2, y2 = self.roi_patches[self.active_roi_index]
        dx = dy = 2  # Move step size
        
        if event.key == 'delete':
            self._delete_roi()
        elif event.key == 'up':
            y1 = max(0, y1 - dy)
            y2 = max(0, y2 - dy)
        elif event.key == 'down':
            y1 = min(self.current_hsi_data.shape[0], y1 + dy)
            y2 = min(self.current_hsi_data.shape[0], y2 + dy)
        elif event.key == 'left':
            x1 = max(0, x1 - dx)
            x2 = max(0, x2 - dx)
        elif event.key == 'right':
            x1 = min(self.current_hsi_data.shape[1], x1 + dx)
            x2 = min(self.current_hsi_data.shape[1], x2 + dx)
        else:
            return
        
        # Update ROI coordinates
        self.roi_patches[self.active_roi_index] = (x1, y1, x2, y2)
        
        # Extract spectrum
        self._extract_spectrum(self.active_roi_index)
        
        # Update displays
        self._update_roi_display()
        self._update_spectrum_display()
        
        self.canvas.draw()
    
    def _on_band_slider(self, value):
        """Handle band slider movement"""
        band = int(float(value))
        self.band_var.set(band)
        self._update_band_display()
    
    def _on_file_select(self, event):
        """Handle file list selection"""
        selection = self.file_listbox.curselection()
        if selection:
            self.current_file_index = selection[0]
            self._load_file(self.file_list[self.current_file_index])
    
    def _on_roi_select(self, event):
        """Handle ROI list selection"""
        selection = self.roi_listbox.curselection()
        if selection:
            self.active_roi_index = selection[0]
            self._update_roi_display()
            self.canvas.draw()
    
    def _update_band_display(self):
        """Update band display"""
        if self.current_hsi_data is None:
            return
        
        band = self.band_var.get()
        if band < 0 or band >= self.current_hsi_data.shape[2]:
            return
        
        # Update image display
        self.ax_img.clear()
        current_image = self.current_hsi_data[:, :, band]
        im = self.ax_img.imshow(current_image, cmap='gray')
        self.ax_img.set_title(f'Band {band} ({self.current_wavelengths[band]:.1f} nm)')
        
        # Update ROI display
        self._update_roi_display()
        
        self.canvas.draw()
    
    def _update_roi_display(self):
        """Update ROI display on image with enhanced visualization"""
        # Clear existing patches and text
        for patch in self.ax_img.patches:
            patch.remove()
        for text in self.ax_img.texts:
            text.remove()
        
        # Draw all ROI patches with enhanced styling
        for i, (coords, color) in enumerate(zip(self.roi_patches, self.roi_colors)):
            x1, y1, x2, y2 = coords
            
            # Enhanced styling for active vs inactive ROIs
            if i == self.active_roi_index:
                # Active ROI: thicker border, higher opacity
                rect = Rectangle((x1, y1), x2-x1, y2-y1, 
                               fill=False, edgecolor=color, linewidth=3,
                               alpha=0.9)
            else:
                # Inactive ROI: normal styling
                rect = Rectangle((x1, y1), x2-x1, y2-y1, 
                               fill=False, edgecolor=color, linewidth=2,
                               alpha=0.6)
            
            self.ax_img.add_patch(rect)
            
            # Add ROI number label at center
            center_x = (x1 + x2) / 2
            center_y = (y1 + y2) / 2
            self.ax_img.text(center_x, center_y, str(i), 
                           color='white', fontsize=10, fontweight='bold',
                           ha='center', va='center',
                           bbox=dict(boxstyle="circle,pad=0.3", 
                                   facecolor=color, alpha=0.8, 
                                   edgecolor='white', linewidth=1))
        
        self.canvas.draw()
    
    def _update_spectrum_display(self):
        """Update spectrum display"""
        self.spectrum_ax.clear()
        
        if self.roi_spectra and any(spectrum is not None for spectrum in self.roi_spectra):
            for i, (spectrum, color, label) in enumerate(zip(self.roi_spectra, self.roi_colors, self.roi_labels)):
                if spectrum is not None:
                    self.spectrum_ax.plot(self.current_wavelengths, spectrum, 
                                        color=color, linewidth=2, label=label)
            
            self.spectrum_ax.set_xlabel('Wavelength (nm)')
            self.spectrum_ax.set_ylabel('Reflectance')
            self.spectrum_ax.set_title('ROI Spectra Comparison')
            self.spectrum_ax.grid(True, alpha=0.3)
            self.spectrum_ax.legend()
        else:
            self.spectrum_ax.set_xlabel('Wavelength (nm)')
            self.spectrum_ax.set_ylabel('Reflectance')
            self.spectrum_ax.set_title('ROI Spectra Comparison')
            self.spectrum_ax.grid(True, alpha=0.3)
        
        self.spectrum_canvas.draw()
    
    def _update_roi_list(self):
        """Update ROI listbox"""
        self.roi_listbox.delete(0, tk.END)
        for i, label in enumerate(self.roi_labels):
            self.roi_listbox.insert(tk.END, f"{i}: {label}")
    
    def _extract_spectrum(self, roi_index):
        """Extract spectrum from ROI"""
        if self.current_hsi_data is None or roi_index >= len(self.roi_patches):
            return
        
        x1, y1, x2, y2 = self.roi_patches[roi_index]
        
        # Extract ROI pixels
        roi_pixels = self.current_hsi_data[y1:y2, x1:x2, :]
        
        # Calculate average spectrum
        if roi_pixels.size > 0:
            mean_spectrum = np.mean(roi_pixels.reshape(-1, self.current_hsi_data.shape[2]), axis=0)
            self.roi_spectra[roi_index] = mean_spectrum
    
    def _add_roi(self):
        """Add ROI at center of image"""
        if self.current_hsi_data is None:
            messagebox.showwarning("Warning", "No image loaded")
            return
        
        # Add ROI at center
        height, width = self.current_hsi_data.shape[:2]
        size = min(height, width) // 10
        x1 = width // 2 - size
        y1 = height // 2 - size
        x2 = width // 2 + size
        y2 = height // 2 + size
        
        # Add new ROI
        color = list(mcolors.TABLEAU_COLORS.values())[len(self.roi_patches) % len(mcolors.TABLEAU_COLORS)]
        self.roi_patches.append((x1, y1, x2, y2))
        self.roi_colors.append(color)
        self.roi_spectra.append(None)
        self.roi_labels.append(f"ROI {len(self.roi_patches)}")
        self.active_roi_index = len(self.roi_patches) - 1
        
        # Extract spectrum
        self._extract_spectrum(self.active_roi_index)
        
        # Update displays
        self._update_roi_display()
        self._update_spectrum_display()
        self._update_roi_list()
        
        self.canvas.draw()
    
    def _delete_roi(self):
        """Delete active ROI"""
        if self.active_roi_index is None:
            return
        
        # Remove ROI data
        self.roi_patches.pop(self.active_roi_index)
        self.roi_spectra.pop(self.active_roi_index)
        self.roi_colors.pop(self.active_roi_index)
        self.roi_labels.pop(self.active_roi_index)
        
        # Update active index
        if self.roi_patches:
            self.active_roi_index = min(self.active_roi_index, len(self.roi_patches) - 1)
        else:
            self.active_roi_index = None
        
        # Update displays
        self._update_roi_display()
        self._update_spectrum_display()
        self._update_roi_list()
        
        self.canvas.draw()
    
    def _clear_rois(self):
        """Clear all ROIs"""
        self.roi_patches = []
        self.roi_spectra = []
        self.roi_colors = []
        self.roi_labels = []
        self.active_roi_index = None
        
        # Update displays
        self._update_roi_display()
        self._update_spectrum_display()
        self._update_roi_list()
        
        self.canvas.draw()
    
    def _update_roi_label(self):
        """Update ROI label"""
        if self.active_roi_index is None:
            messagebox.showwarning("Warning", "No ROI selected")
            return
        
        new_label = self.roi_label_var.get().strip()
        if new_label:
            self.roi_labels[self.active_roi_index] = new_label
            self._update_roi_list()
    
    def _save_image(self):
        """Save current image with ROIs to file using matplotlib's savefig"""
        if self.current_hsi_data is None:
            messagebox.showwarning("Warning", "No image loaded")
            return
        
        # Generate default filename: source filename + "_image" + current band + extension
        if self.current_file_path:
            base_name = os.path.splitext(os.path.basename(self.current_file_path))[0]
            default_name = f"{base_name}_band{self.band_var.get()}.png"
            default_dir = os.path.dirname(self.current_file_path)
        else:
            default_name = "hyperspectral_image.png"
            default_dir = ""
        
        # File dialog
        file_path = filedialog.asksaveasfilename(
            title="Save Image",
            defaultextension=".png",
            initialfile=default_name,
            initialdir=default_dir,
            filetypes=[
                ("PNG files", "*.png"),
                ("JPEG files", "*.jpg"),
                ("PDF files", "*.pdf"), 
                ("SVG files", "*.svg"),
                ("All files", "*.*")
            ]
        )
        
        if file_path:
            try:
                # Use matplotlib's savefig to save the image
                self.fig.savefig(file_path, dpi=300, bbox_inches='tight', pad_inches=0.1)
                messagebox.showinfo("Success", f"Image saved to {file_path}")
            except Exception as e:
                messagebox.showerror("Error", f"Failed to save image: {e}")

    def _save_spectrum_fig(self):
        """Save spectrum figure to file using matplotlib's savefig"""
        if not self.roi_spectra or not any(spectrum is not None for spectrum in self.roi_spectra):
            messagebox.showwarning("Warning", "No spectrum data to save")
            return
        
        # Generate default filename: source filename + "_spectrum" + extension
        if self.current_file_path:
            base_name = os.path.splitext(os.path.basename(self.current_file_path))[0]
            default_name = f"{base_name}_spectrum.png"
            default_dir = os.path.dirname(self.current_file_path)
        else:
            default_name = "spectrum_plot.png"
            default_dir = ""
        
        # File dialog
        file_path = filedialog.asksaveasfilename(
            title="Save Spectrum Plot",
            defaultextension=".png",
            initialfile=default_name,
            initialdir=default_dir,
            filetypes=[
                ("PNG files", "*.png"),
                ("JPEG files", "*.jpg"),
                ("PDF files", "*.pdf"), 
                ("SVG files", "*.svg"),
                ("All files", "*.*")
            ]
        )
        
        if file_path:
            try:
                # Use matplotlib's savefig to save the spectrum figure
                self.spectrum_fig.savefig(file_path, dpi=300, bbox_inches='tight', pad_inches=0.1)
                messagebox.showinfo("Success", f"Spectrum plot saved to {file_path}")
            except Exception as e:
                messagebox.showerror("Error", f"Failed to save spectrum plot: {e}")
    
    def _get_default_csv_path(self, hsi_file_path):
        """Get default CSV file path for the given HSI file"""
        base_name = os.path.splitext(os.path.basename(hsi_file_path))[0]
        dir_path = os.path.dirname(hsi_file_path)
        return os.path.join(dir_path, f"{base_name}.csv")
    
    def _auto_save_current_rois(self):
        """Automatically save current ROI data before loading new file"""
        if not self.current_file_path or not any(spectrum is not None for spectrum in self.roi_spectra):
            return
        
        csv_path = self._get_default_csv_path(self.current_file_path)
        
        try:
            # Prepare data for CSV
            data = []
            for i, ((x1, y1, x2, y2), spectrum, label) in enumerate(
                zip(self.roi_patches, self.roi_spectra, self.roi_labels)):
                
                if spectrum is not None:
                    # Get default values
                    folder_name = os.path.basename(os.path.dirname(self.current_file_path))
                    current_time = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                    
                    # Create row data
                    row_data = {
                        'roi_index': i,
                        'label': label,
                        'name': folder_name,
                        'note': current_time,
                        'x1': x1,
                        'y1': y1,
                        'x2': x2,
                        'y2': y2
                    }
                    
                    # Add spectrum data (each band as separate column)
                    for band_idx, value in enumerate(spectrum):
                        row_data[f'band_{band_idx}'] = value
                    
                    data.append(row_data)
            
            if data:
                df = pd.DataFrame(data)
                df.to_csv(csv_path, index=False)
                logger.info(f"Auto-saved {len(data)} ROIs to {csv_path}")
        
        except Exception as e:
            logger.error(f"Failed to auto-save ROIs: {e}")
    
    def _auto_load_rois_from_csv(self, hsi_file_path):
        """Automatically load ROI data from CSV file if exists"""
        csv_path = self._get_default_csv_path(hsi_file_path)
        
        if not os.path.exists(csv_path):
            return False
        
        try:
            # Load CSV data
            df = pd.read_csv(csv_path)
            
            # Clear existing ROIs
            self.roi_patches = []
            self.roi_spectra = []
            self.roi_labels = []
            self.roi_colors = []
            
            # Process each row
            for _, row in df.iterrows():
                # Extract ROI coordinates
                x1 = int(row['x1'])
                y1 = int(row['y1'])
                x2 = int(row['x2'])
                y2 = int(row['y2'])
                
                # Extract spectrum data (all band_* columns)
                spectrum_columns = [col for col in df.columns if col.startswith('band_')]
                spectrum = [row[col] for col in spectrum_columns]
                
                # Extract metadata
                label = str(row.get('label', f"ROI {len(self.roi_patches)}"))
                name = str(row.get('name', ''))
                note = str(row.get('note', ''))
                
                # Add ROI data
                self.roi_patches.append((x1, y1, x2, y2))
                self.roi_spectra.append(np.array(spectrum))
                self.roi_labels.append(label)
                
                # Assign color
                color = list(mcolors.TABLEAU_COLORS.values())[len(self.roi_patches) % len(mcolors.TABLEAU_COLORS)]
                self.roi_colors.append(color)
            
            # Update displays
            self._update_roi_list()
            self._update_spectrum_display()
            
            logger.info(f"Auto-loaded {len(self.roi_patches)} ROIs from {csv_path}")
            return True
            
        except Exception as e:
            logger.error(f"Failed to auto-load ROIs from {csv_path}: {e}")
            return False
    
    def _save_spectra(self):
        """Save all spectra to CSV with enhanced format"""
        if not any(spectrum is not None for spectrum in self.roi_spectra):
            messagebox.showwarning("Warning", "No spectrum data to save")
            return
        
        # Get default file path
        default_path = self._get_default_csv_path(self.current_file_path) if self.current_file_path else ""
        
        file_path = filedialog.asksaveasfilename(
            title="Save Spectra Data",
            defaultextension=".csv",
            initialfile=os.path.basename(default_path) if default_path else "",
            initialdir=os.path.dirname(default_path) if default_path else "",
            filetypes=[("CSV files", "*.csv"), ("All files", "*.*")]
        )
        
        if not file_path:
            return
        
        try:
            # Prepare data for CSV
            data = []
            for i, ((x1, y1, x2, y2), spectrum, label) in enumerate(
                zip(self.roi_patches, self.roi_spectra, self.roi_labels)):
                
                if spectrum is not None:
                    # Get default values
                    folder_name = os.path.basename(os.path.dirname(self.current_file_path)) if self.current_file_path else "unknown"
                    current_time = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                    
                    # Create row data
                    row_data = {
                        'roi_index': i,
                        'label': label,
                        'name': folder_name,
                        'note': current_time,
                        'x1': x1,
                        'y1': y1,
                        'x2': x2,
                        'y2': y2
                    }
                    
                    # Add spectrum data (each band as separate column)
                    for band_idx, value in enumerate(spectrum):
                        row_data[f'band_{band_idx}'] = value
                    
                    data.append(row_data)
            
            if data:
                df = pd.DataFrame(data)
                df.to_csv(file_path, index=False)
                messagebox.showinfo("Success", f"Spectra saved to {file_path}")
            else:
                messagebox.showwarning("Warning", "No valid spectrum data to save")
            
        except Exception as e:
            messagebox.showerror("Error", f"Failed to save spectra: {e}")
    
    def _load_single_file(self):
        """Load a single file"""
        file_types = [
            ("Hyperspectral Files", "*.hdr *.mat *.dat *.img *.raw"),
            ("ENVI Files", "*.hdr"),
            ("MATLAB Files", "*.mat"),
            ("All Files", "*.*")
        ]
        
        file_path = filedialog.askopenfilename(
            title="Select Hyperspectral File",
            filetypes=file_types
        )
        
        if file_path:
            self.file_list = [file_path]
            self.file_listbox.delete(0, tk.END)
            self.file_listbox.insert(tk.END, os.path.basename(file_path))
            self.current_file_index = 0
            self._load_file(file_path)
            self.file_info_var.set(f"1 file loaded")
            self.file_nav_var.set(f"1/1")
    
    def _add_files(self):
        """Add files to batch list"""
        file_types = [
            ("Hyperspectral Files", "*.hdr *.mat *.dat *.img *.raw"),
            ("ENVI Files", "*.hdr"),
            ("MATLAB Files", "*.mat"),
            ("All Files", "*.*")
        ]
        
        files = filedialog.askopenfilenames(
            title="Select Hyperspectral Files",
            filetypes=file_types
        )
        
        if files:
            self._add_to_file_list(files)
    
    def _add_folder(self):
        """Add folder to batch list"""
        folder = filedialog.askdirectory(title="Select Folder with Hyperspectral Files")
        
        if folder:
            # Find files matching the filter
            filter_pattern = self.filter_var.get()
            files = glob.glob(os.path.join(folder, filter_pattern))
            
            if files:
                self._add_to_file_list(files)
            else:
                messagebox.showinfo("Info", f"No files found matching {filter_pattern}")
    
    def _add_to_file_list(self, files):
        """Add files to the file list"""
        for file_path in files:
            if file_path not in self.file_list:
                self.file_list.append(file_path)
                self.file_listbox.insert(tk.END, os.path.basename(file_path))
        
        self.file_info_var.set(f"{len(self.file_list)} files loaded")
        self.file_nav_var.set(f"{self.current_file_index + 1 if self.current_file_index >= 0 else 0}/{len(self.file_list)}")
    
    def _clear_file_list(self):
        """Clear file list"""
        self.file_list = []
        self.file_listbox.delete(0, tk.END)
        self.file_info_var.set("No files loaded")
        self.file_nav_var.set("0/0")
        self.current_file_index = -1
    
    def _process_selected(self):
        """Process selected files"""
        selection = self.file_listbox.curselection()
        if not selection:
            messagebox.showwarning("Warning", "No files selected")
            return
        
        selected_files = [self.file_list[i] for i in selection]
        self._process_files(selected_files)
    
    def _process_all(self):
        """Process all files"""
        if not self.file_list:
            messagebox.showwarning("Warning", "No files to process")
            return
        
        self._process_files(self.file_list)
    
    def _process_files(self, files):
        """Process multiple files"""
        # This would be implemented for batch processing
        messagebox.showinfo("Info", f"Batch processing for {len(files)} files would be implemented here")
    
    def _prev_file(self):
        """Load previous file"""
        if len(self.file_list) <= 1:
            return
        
        self.current_file_index = (self.current_file_index - 1) % len(self.file_list)
        self._load_file(self.file_list[self.current_file_index])
        self.file_nav_var.set(f"{self.current_file_index + 1}/{len(self.file_list)}")
    
    def _next_file(self):
        """Load next file"""
        if len(self.file_list) <= 1:
            return
        
        self.current_file_index = (self.current_file_index + 1) % len(self.file_list)
        self._load_file(self.file_list[self.current_file_index])
        self.file_nav_var.set(f"{self.current_file_index + 1}/{len(self.file_list)}")
    
    def _load_file(self, file_path):
        """Load hyperspectral file with auto-save and auto-load functionality"""
        try:
            # Auto-save current ROIs before loading new file
            if self.current_file_path and any(spectrum is not None for spectrum in self.roi_spectra):
                self._auto_save_current_rois()
            
            self.status_var.set(f"Loading {os.path.basename(file_path)}...")
            self.root.update()
            
            # Load the file
            hsi_data, wavelengths, metadata = self.data_loader.load_file(file_path)
            
            if hsi_data is None:
                messagebox.showerror("Error", f"Failed to load file: {file_path}")
                self.status_var.set("Load failed")
                return
            
            self.current_hsi_data = hsi_data
            self.current_wavelengths = wavelengths
            self.current_file_path = file_path
            
            # Clear existing ROIs
            self._clear_rois()
            
            # Try to auto-load ROIs from CSV
            loaded = self._auto_load_rois_from_csv(file_path)
            if loaded:
                self.status_var.set(f"Loaded: {os.path.basename(file_path)} (with {len(self.roi_patches)} ROIs)")
            else:
                self.status_var.set(f"Loaded: {os.path.basename(file_path)}")
            
            # Update band controls
            max_band = hsi_data.shape[2] - 1
            self.band_spinbox.configure(from_=0, to=max_band)
            self.band_scale.configure(from_=0, to=max_band)
            self.band_var.set(0)
            
            # Update display
            self._update_band_display()
            
        except Exception as e:
            messagebox.showerror("Error", f"Error loading file: {e}")
            self.status_var.set("Load error")
        finally:
            self.root.update()
    
    def run(self):
        """Run the application"""
        self.root.mainloop()

def main():
    """Main entry point"""
    app = UnifiedHyperspectralViewer()
    app.run()

if __name__ == "__main__":
    main()
