"""
ROI Processor Module - Handles Region of Interest extraction and processing
"""

import numpy as np
from typing import Tuple, List, Dict, Any, Optional
import logging

from ..utils.logger import LoggingMixin
from ..utils.validation import validate_roi_coordinates, validate_spectral_data

logger = logging.getLogger(__name__)

class ROIProcessor(LoggingMixin):
    """Handles extraction and processing of Regions of Interest"""
    
    def __init__(self):
        super().__init__()
    
    def extract_roi_spectrum(
        self, 
        hsi_data: np.ndarray, 
        coordinates: Tuple[int, int, int, int],
        method: str = 'mean'
    ) -> Tuple[Optional[np.ndarray], Dict[str, Any]]:
        """
        Extract spectral data from ROI
        
        Args:
            hsi_data: Hyperspectral data cube
            coordinates: (x1, y1, x2, y2) ROI coordinates
            method: Extraction method ('mean', 'median', 'max', 'min')
            
        Returns:
            Tuple of (spectral_data, metadata) or (None, {}) on failure
        """
        try:
            # Validate coordinates
            is_valid, message = validate_roi_coordinates(coordinates, hsi_data.shape)
            if not is_valid:
                self.log_error(f"Invalid ROI coordinates: {message}")
                return None, {}
            
            x1, y1, x2, y2 = coordinates
            
            # Extract ROI data
            roi_data = hsi_data[y1:y2, x1:x2, :]
            
            # Apply extraction method
            if method == 'mean':
                spectral_data = np.mean(roi_data, axis=(0, 1))
            elif method == 'median':
                spectral_data = np.median(roi_data, axis=(0, 1))
            elif method == 'max':
                spectral_data = np.max(roi_data, axis=(0, 1))
            elif method == 'min':
                spectral_data = np.min(roi_data, axis=(0, 1))
            else:
                self.log_error(f"Unknown extraction method: {method}")
                return None, {}
            
            # Validate spectral data
            is_valid, message = validate_spectral_data(spectral_data, hsi_data.shape[2])
            if not is_valid:
                self.log_error(f"Spectral data validation failed: {message}")
                return None, {}
            
            # Create metadata
            metadata = {
                'coordinates': coordinates,
                'roi_size': (x2 - x1, y2 - y1),
                'pixel_count': (x2 - x1) * (y2 - y1),
                'extraction_method': method,
                'data_range': (np.min(spectral_data), np.max(spectral_data))
            }
            
            self.log_info(f"Extracted ROI spectrum: {spectral_data.shape}, method: {method}")
            return spectral_data, metadata
            
        except Exception as e:
            self.log_error(f"Error extracting ROI spectrum: {e}")
            return None, {}
    
    def extract_multiple_rois(
        self, 
        hsi_data: np.ndarray, 
        rois: List[Tuple[int, int, int, int]],
        method: str = 'mean'
    ) -> Tuple[List[np.ndarray], List[Dict[str, Any]]]:
        """
        Extract spectra from multiple ROIs
        
        Args:
            hsi_data: Hyperspectral data cube
            rois: List of ROI coordinates
            method: Extraction method
            
        Returns:
            Tuple of (spectra_list, metadata_list)
        """
        spectra = []
        metadata_list = []
        
        for i, roi_coords in enumerate(rois):
            spectral_data, roi_metadata = self.extract_roi_spectrum(hsi_data, roi_coords, method)
            if spectral_data is not None:
                spectra.append(spectral_data)
                metadata_list.append(roi_metadata)
                self.log_info(f"Processed ROI {i+1}/{len(rois)}")
            else:
                self.log_warning(f"Failed to process ROI {i+1}")
        
        return spectra, metadata_list
    
    def calculate_roi_statistics(
        self, 
        hsi_data: np.ndarray, 
        coordinates: Tuple[int, int, int, int]
    ) -> Dict[str, Any]:
        """
        Calculate statistics for ROI
        
        Args:
            hsi_data: Hyperspectral data cube
            coordinates: ROI coordinates
            
        Returns:
            Dictionary with ROI statistics
        """
        try:
            x1, y1, x2, y2 = coordinates
            roi_data = hsi_data[y1:y2, x1:x2, :]
            
            stats = {
                'mean': np.mean(roi_data, axis=(0, 1)),
                'std': np.std(roi_data, axis=(0, 1)),
                'min': np.min(roi_data, axis=(0, 1)),
                'max': np.max(roi_data, axis=(0, 1)),
                'median': np.median(roi_data, axis=(0, 1)),
                'size': roi_data.shape[:2],
                'pixel_count': roi_data.shape[0] * roi_data.shape[1]
            }
            
            return stats
            
        except Exception as e:
            self.log_error(f"Error calculating ROI statistics: {e}")
            return {}
    
    def create_roi_mask(
        self, 
        image_shape: Tuple[int, int], 
        coordinates: Tuple[int, int, int, int]
    ) -> np.ndarray:
        """
        Create binary mask for ROI
        
        Args:
            image_shape: (height, width) of the image
            coordinates: ROI coordinates
            
        Returns:
            Binary mask array
        """
        try:
            mask = np.zeros(image_shape[:2], dtype=bool)
            x1, y1, x2, y2 = coordinates
            mask[y1:y2, x1:x2] = True
            return mask
            
        except Exception as e:
            self.log_error(f"Error creating ROI mask: {e}")
            return np.zeros(image_shape[:2], dtype=bool)
    
    def validate_roi_overlap(
        self, 
        roi1: Tuple[int, int, int, int], 
        roi2: Tuple[int, int, int, int]
    ) -> bool:
        """
        Check if two ROIs overlap
        
        Args:
            roi1: First ROI coordinates
            roi2: Second ROI coordinates
            
        Returns:
            True if ROIs overlap, False otherwise
        """
        x1_1, y1_1, x2_1, y2_1 = roi1
        x1_2, y1_2, x2_2, y2_2 = roi2
        
        # Check for non-overlap conditions
        if (x2_1 <= x1_2 or x2_2 <= x1_1 or 
            y2_1 <= y1_2 or y2_2 <= y1_1):
            return False
        
        return True
    
    def merge_overlapping_rois(
        self, 
        rois: List[Tuple[int, int, int, int]]
    ) -> List[Tuple[int, int, int, int]]:
        """
        Merge overlapping ROIs
        
        Args:
            rois: List of ROI coordinates
            
        Returns:
            List of merged ROI coordinates
        """
        if not rois:
            return []
        
        # Sort ROIs by x1 coordinate
        sorted_rois = sorted(rois, key=lambda roi: roi[0])
        merged = []
        
        current_roi = sorted_rois[0]
        
        for roi in sorted_rois[1:]:
            if self.validate_roi_overlap(current_roi, roi):
                # Merge overlapping ROIs
                x1 = min(current_roi[0], roi[0])
                y1 = min(current_roi[1], roi[1])
                x2 = max(current_roi[2], roi[2])
                y2 = max(current_roi[3], roi[3])
                current_roi = (x1, y1, x2, y2)
            else:
                merged.append(current_roi)
                current_roi = roi
        
        merged.append(current_roi)
        return merged
    
    def calculate_roi_centroid(
        self, 
        coordinates: Tuple[int, int, int, int]
    ) -> Tuple[float, float]:
        """
        Calculate centroid of ROI
        
        Args:
            coordinates: ROI coordinates
            
        Returns:
            (center_x, center_y) coordinates
        """
        x1, y1, x2, y2 = coordinates
        center_x = (x1 + x2) / 2.0
        center_y = (y1 + y2) / 2.0
        return center_x, center_y
    
    def expand_roi(
        self, 
        coordinates: Tuple[int, int, int, int], 
        pixels: int,
        image_shape: Tuple[int, int]
    ) -> Tuple[int, int, int, int]:
        """
        Expand ROI by specified number of pixels
        
        Args:
            coordinates: Original ROI coordinates
            pixels: Number of pixels to expand
            image_shape: Image dimensions for boundary checking
            
        Returns:
            Expanded ROI coordinates
        """
        x1, y1, x2, y2 = coordinates
        height, width = image_shape
        
        # Expand coordinates
        new_x1 = max(0, x1 - pixels)
        new_y1 = max(0, y1 - pixels)
        new_x2 = min(width, x2 + pixels)
        new_y2 = min(height, y2 + pixels)
        
        return new_x1, new_y1, new_x2, new_y2
    
    def shrink_roi(
        self, 
        coordinates: Tuple[int, int, int, int], 
        pixels: int
    ) -> Tuple[int, int, int, int]:
        """
        Shrink ROI by specified number of pixels
        
        Args:
            coordinates: Original ROI coordinates
            pixels: Number of pixels to shrink
            
        Returns:
            Shrunk ROI coordinates
        """
        x1, y1, x2, y2 = coordinates
        
        # Shrink coordinates
        new_x1 = x1 + pixels
        new_y1 = y1 + pixels
        new_x2 = x2 - pixels
        new_y2 = y2 - pixels
        
        # Ensure valid ROI
        if new_x1 >= new_x2 or new_y1 >= new_y2:
            # Return original if shrinking would invalidate ROI
            return coordinates
        
        return new_x1, new_y1, new_x2, new_y2
