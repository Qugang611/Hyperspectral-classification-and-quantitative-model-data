"""
Data Loader Module - Handles loading of hyperspectral data files
"""

import os
import numpy as np
from scipy.io import loadmat
import spectral as spy
from typing import Tuple, Optional, Dict, Any, List
import logging

from ..utils.logger import LoggingMixin
from ..utils.validation import validate_hyperspectral_data

logger = logging.getLogger(__name__)

def check_and_add_byte_order(hdr_file: str) -> bool:
    """
    Check and possibly add "byte order = 0" to .hdr file
    
    Args:
        hdr_file: Path to .hdr file
        
    Returns:
        True if successful or already exists, False if failed
    """
    try:
        # Try to read file content
        with open(hdr_file, 'r', encoding='utf-8', errors='ignore') as f:
            lines = f.readlines()
        
        # Check if "byte order" parameter already exists (not necessarily 0)
        found_byte_order = False
        for line in lines:
            if 'byte order' in line.lower():
                found_byte_order = True
                break
        
        # If not found, add the line
        if not found_byte_order:
            with open(hdr_file, 'a') as f:
                f.write('\nbyte order = 0\n')
            logger.info(f"Added 'byte order = 0' to {hdr_file}")
            return True
        else:
            logger.debug(f"{hdr_file} already has 'byte order' parameter")
            return True
            
    except FileNotFoundError:
        logger.error(f"File not found: {hdr_file}")
        return False
    except Exception as e:
        logger.error(f"Error processing file {hdr_file}: {str(e)}")
        return False

class DataLoader(LoggingMixin):
    """Handles loading of various hyperspectral data formats"""
    
    def __init__(self):
        super().__init__()
        self.supported_formats = ['.mat', '.hdr', '.dat', '.img', '.raw']
    
    def load_file(self, file_path: str) -> Tuple[Optional[np.ndarray], Optional[np.ndarray], Dict[str, Any]]:
        """
        Load hyperspectral data from file
        
        Args:
            file_path: Path to hyperspectral file
            
        Returns:
            Tuple of (data, wavelengths, metadata) or (None, None, {}) on failure
        """
        try:
            file_ext = os.path.splitext(file_path)[1].lower()
            
            if file_ext == '.mat':
                return self._load_mat_file(file_path)
            elif file_ext == '.hdr':
                return self._load_envi_file(file_path)
            elif file_ext in ['.dat', '.img', '.raw']:
                return self._load_raw_file(file_path)
            else:
                self.log_error(f"Unsupported file format: {file_ext}")
                return None, None, {}
                
        except Exception as e:
            self.log_error(f"Error loading file {file_path}: {e}")
            return None, None, {}
    
    def _load_mat_file(self, file_path: str) -> Tuple[Optional[np.ndarray], Optional[np.ndarray], Dict[str, Any]]:
        """Load MATLAB .mat file"""
        try:
            mat_data = loadmat(file_path)
            metadata = {}
            
            # Try to find image data
            hsi_data = None
            for key in mat_data.keys():
                if not key.startswith('__') and len(mat_data[key].shape) >= 3:
                    hsi_data = mat_data[key]
                    metadata['data_key'] = key
                    break
            
            if hsi_data is None:
                self.log_error("No hyperspectral data found in MAT file")
                return None, None, {}
            
            # Generate simulated wavelengths if not available
            if 'wavelength' in mat_data:
                wavelengths = mat_data['wavelength'].flatten()
                metadata['wavelength_source'] = 'file'
            else:
                wavelengths = np.linspace(400, 1000, hsi_data.shape[2])
                metadata['wavelength_source'] = 'simulated'
                self.log_warning("Using simulated wavelengths (400-1000nm)")
            
            # Validate data
            is_valid, message = validate_hyperspectral_data(hsi_data, wavelengths)
            if not is_valid:
                self.log_error(f"Data validation failed: {message}")
                return None, None, {}
            
            metadata['file_type'] = 'mat'
            metadata['dimensions'] = hsi_data.shape
            metadata['bands'] = hsi_data.shape[2]
            
            self.log_info(f"Successfully loaded MAT file: {hsi_data.shape}")
            return hsi_data, wavelengths, metadata
            
        except Exception as e:
            self.log_error(f"Error loading MAT file {file_path}: {e}")
            return None, None, {}
    
    def _load_envi_file(self, file_path: str) -> Tuple[Optional[np.ndarray], Optional[np.ndarray], Dict[str, Any]]:
        """Load ENVI .hdr file"""
        try:
            # First check and fix ENVI header if needed
            self.log_info("Checking ENVI header file...")
            if not check_and_add_byte_order(file_path):
                self.log_warning("Failed to fix ENVI header, trying to load anyway...")
            
            # Try to load ENVI file using spectral library
            try:
                img = spy.open_image(file_path)
                hsi_data = img.load()
                
                # Try to get wavelength information
                wavelengths = None
                if 'wavelength' in img.metadata:
                    try:
                        wavelengths_str = img.metadata['wavelength']
                        wavelengths = np.array([float(w) for w in wavelengths_str])
                        metadata = {'wavelength_source': 'file'}
                    except Exception as e:
                        self.log_warning(f"Error parsing wavelengths: {e}")
                        wavelengths = None
                
                if wavelengths is None:
                    wavelengths = np.linspace(400, 1000, hsi_data.shape[2])
                    metadata = {'wavelength_source': 'simulated'}
                    self.log_warning("Using simulated wavelengths (400-1000nm)")
                
                # Validate data
                is_valid, message = validate_hyperspectral_data(hsi_data, wavelengths)
                if not is_valid:
                    self.log_error(f"Data validation failed: {message}")
                    return None, None, {}
                
                metadata['file_type'] = 'envi'
                metadata['dimensions'] = hsi_data.shape
                metadata['bands'] = hsi_data.shape[2]
                metadata.update(img.metadata)
                
                self.log_info(f"Successfully loaded ENVI file: {hsi_data.shape}")
                return hsi_data, wavelengths, metadata
                
            except Exception as e:
                self.log_error(f"ENVI file loading error: {e}")
                return self._load_raw_file(file_path)
                
        except Exception as e:
            self.log_error(f"Error loading ENVI file {file_path}: {e}")
            return None, None, {}
    
    def _load_raw_file(self, file_path: str) -> Tuple[Optional[np.ndarray], Optional[np.ndarray], Dict[str, Any]]:
        """Load raw data file with corresponding .hdr"""
        try:
            # Get the data file name from header
            base_name = os.path.splitext(file_path)[0]
            data_file = base_name
            
            # Try common extensions
            for ext in ['.dat', '.img', '.raw', '.bin']:
                if os.path.exists(base_name + ext):
                    data_file = base_name + ext
                    break
            
            if not os.path.exists(data_file):
                self.log_error(f"Data file not found for {file_path}")
                return None, None, {}
            
            # Read header to get dimensions
            hdr_file = base_name + '.hdr'
            if not os.path.exists(hdr_file):
                self.log_error(f"Header file not found: {hdr_file}")
                return None, None, {}
            
            with open(hdr_file, 'r') as f:
                header_content = f.read()
            
            # Parse dimensions from header
            lines = header_content.split('\n')
            samples = 0
            lines_count = 0
            bands = 0
            for line in lines:
                line_lower = line.lower()
                if 'samples' in line_lower:
                    samples = int(line.split('=')[1].strip())
                elif 'lines' in line_lower:
                    lines_count = int(line.split('=')[1].strip())
                elif 'bands' in line_lower:
                    bands = int(line.split('=')[1].strip())
            
            if samples <= 0 or lines_count <= 0 or bands <= 0:
                self.log_error("Could not parse dimensions from header")
                return None, None, {}
            
            # Read raw data (assuming float32)
            hsi_data = np.fromfile(data_file, dtype=np.float32)
            if len(hsi_data) != lines_count * samples * bands:
                self.log_error("Data size doesn't match header dimensions")
                return None, None, {}
            
            hsi_data = hsi_data.reshape((lines_count, samples, bands))
            wavelengths = np.linspace(400, 1000, bands)
            
            # Validate data
            is_valid, message = validate_hyperspectral_data(hsi_data, wavelengths)
            if not is_valid:
                self.log_error(f"Data validation failed: {message}")
                return None, None, {}
            
            metadata = {
                'file_type': 'raw',
                'dimensions': hsi_data.shape,
                'bands': bands,
                'wavelength_source': 'simulated'
            }
            
            self.log_info(f"Successfully loaded raw file: {hsi_data.shape}")
            return hsi_data, wavelengths, metadata
            
        except Exception as e:
            self.log_error(f"Error loading raw file {file_path}: {e}")
            return None, None, {}
    
    def get_file_info(self, file_path: str) -> Dict[str, Any]:
        """
        Get information about hyperspectral file without loading full data
        
        Args:
            file_path: Path to file
            
        Returns:
            Dictionary with file information
        """
        try:
            file_ext = os.path.splitext(file_path)[1].lower()
            info = {
                'path': file_path,
                'name': os.path.basename(file_path),
                'extension': file_ext,
                'size': os.path.getsize(file_path),
                'modified': os.path.getmtime(file_path)
            }
            
            if file_ext == '.mat':
                # Quick peek into MAT file to get dimensions
                mat_data = loadmat(file_path, mat_dtype=True)
                for key in mat_data.keys():
                    if not key.startswith('__') and len(mat_data[key].shape) >= 3:
                        info['dimensions'] = mat_data[key].shape
                        info['bands'] = mat_data[key].shape[2]
                        break
            
            return info
            
        except Exception as e:
            self.log_error(f"Error getting file info for {file_path}: {e}")
            return {'path': file_path, 'error': str(e)}

    def find_supported_files(self, directory: str) -> List[str]:
        """
        Find all supported hyperspectral files in a directory
        
        Args:
            directory: Directory to search
            
        Returns:
            List of supported file paths
        """
        try:
            if not os.path.isdir(directory):
                self.log_error(f"Directory not found: {directory}")
                return []
            
            supported_files = []
            for root, _, files in os.walk(directory):
                for file in files:
                    file_ext = os.path.splitext(file)[1].lower()
                    if file_ext in self.supported_formats:
                        file_path = os.path.join(root, file)
                        supported_files.append(file_path)
            
            self.log_info(f"Found {len(supported_files)} supported files in {directory}")
            return supported_files
            
        except Exception as e:
            self.log_error(f"Error finding supported files in {directory}: {e}")
            return []
