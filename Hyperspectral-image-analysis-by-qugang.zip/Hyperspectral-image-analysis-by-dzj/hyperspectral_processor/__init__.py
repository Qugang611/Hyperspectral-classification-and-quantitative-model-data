"""
高光谱数据处理包 - 批量处理高光谱图像的模块化工具
"""

__version__ = "1.0.0"
__author__ = "Hyperspectral Analysis Team"

from .config.config_manager import ConfigManager
from .utils.logger import setup_logger

# 初始化默认配置和日志
config = ConfigManager()
logger = setup_logger()

__all__ = ['config', 'logger', 'ConfigManager', 'setup_logger']
