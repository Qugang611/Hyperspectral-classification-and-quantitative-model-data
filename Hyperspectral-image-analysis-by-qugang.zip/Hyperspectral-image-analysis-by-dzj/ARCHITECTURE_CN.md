# 统一高光谱查看器 - 架构文档

## 概述

统一高光谱查看器是一个全面的桌面应用程序，设计用于交互式分析高光谱数据。它采用单页界面，集成了图像显示、光谱分析、ROI管理和批处理功能。

## 系统架构

### 高层架构

```mermaid
graph TB
    subgraph "表示层"
        GUI[图形用户界面]
        CV[画布可视化]
        PL[绘图系统]
    end
    
    subgraph "应用层"
        UV[统一查看器控制器]
        EM[事件管理器]
        SM[状态管理器]
    end
    
    subgraph "业务逻辑层"
        DL[数据加载器服务]
        RP[ROI处理器服务]
        FS[文件服务]
        EX[导出服务]
    end
    
    subgraph "数据访问层"
        FD[文件数据访问]
        CD[配置数据]
        RD[ROI数据持久化]
    end
    
    subgraph "基础设施层"
        LG[日志系统]
        CF[配置系统]
        ERR[错误处理]
    end
    
    GUI --> UV
    CV --> UV
    PL --> UV
    
    UV --> DL
    UV --> RP
    UV --> FS
    UV --> EX
    
    DL --> FD
    RP --> FD
    FS --> FD
    EX --> FD
    
    UV --> EM
    UV --> SM
    
    EM --> LG
    SM --> CF
    UV --> ERR
    
    CF --> CD
    EX --> RD
```

## 核心组件

### 1. UnifiedHyperspectralViewer 类

**职责**:
- 主应用程序控制器
- UI初始化和管理
- 事件处理和协调
- 状态管理

**关键属性**:
```python
current_hsi_data: np.ndarray        # 当前高光谱数据立方体
current_wavelengths: np.ndarray     # 波长数组
current_file_path: str              # 当前文件路径
roi_patches: List[Tuple]           # ROI坐标 (x1, y1, x2, y2)
roi_spectra: List[np.ndarray]      # 每个ROI提取的光谱
roi_colors: List[str]              # ROI可视化颜色
active_roi_index: Optional[int]    # 当前选定的ROI索引
roi_labels: List[str]              # 用户定义的ROI标签
```

### 2. DataLoader 服务

**职责**:
- 文件格式检测和加载
- ENVI文件的字节序处理
- 元数据提取
- 数据验证

**支持的格式**:
- ENVI (.hdr + 数据文件)
- MATLAB (.mat)
- 原始二进制文件
- 常见图像格式

### 3. ROIProcessor 服务

**职责**:
- ROI坐标管理
- 从ROI中提取光谱
- ROI数据验证
- 坐标转换

### 4. Export 服务

**职责**:
- 图像导出 (PNG, JPEG, PDF, SVG)
- 带元数据的CSV数据导出
- 自动文件命名
- 质量控制

## 数据流

### 文件加载时序

```mermaid
sequenceDiagram
    participant User
    participant UV as UnifiedViewer
    participant DL as DataLoader
    participant FS as FileSystem
    participant RP as ROIProcessor
    
    User->>UV: 加载文件
    UV->>DL: load_file(file_path)
    DL->>FS: read_file_metadata()
    FS-->>DL: metadata
    DL->>DL: detect_format()
    DL->>DL: validate_data()
    DL->>FS: read_binary_data()
    FS-->>DL: raw_data
    DL->>DL: convert_to_ndarray()
    DL-->>UV: hsi_data, wavelengths, metadata
    
    UV->>UV: clear_existing_rois()
    UV->>UV: try_auto_load_rois()
    UV->>UV: update_band_controls()
    UV->>UV: update_image_display()
    UV-->>User: 显示加载的数据
```

### ROI处理时序

```mermaid
sequenceDiagram
    participant User
    participant UV as UnifiedViewer
    participant RP as ROIProcessor
    participant CV as Canvas
    
    User->>CV: 点击图像
    CV->>UV: canvas_click_event(x, y)
    UV->>UV: check_existing_rois(x, y)
    alt 点击现有ROI
        UV->>UV: set_active_roi(index)
        UV->>UV: update_roi_display()
        UV-->>User: 高亮选定的ROI
    else 创建新ROI
        UV->>UV: create_new_roi(x, y)
        UV->>RP: extract_spectrum(coords)
        RP-->>UV: spectrum_data
        UV->>UV: update_roi_data()
        UV->>UV: update_spectrum_display()
        UV->>UV: update_roi_list()
        UV-->>User: 显示新ROI和光谱
    end
```

## UI架构

### 布局结构

```
主窗口
├── 标题栏
├── 顶部控制区域
│   ├── 文件控制 (加载, 添加文件夹)
│   ├── 过滤器选择
│   └── 导航控制
├── 主内容区域
│   ├── 左侧面板 (60%)
│   │   └── 图像显示和ROI管理
│   │       ├── Matplotlib画布
│   │       ├── 导航工具栏
│   │       ├── 波段控制
│   │       └── ROI控制
│   └── 右侧面板 (40%)
│       ├── 右上: 光谱分析
│       │   └── 光谱图画布
│       └── 右下: 批处理
│           ├── 文件列表框
│           ├── 批处理控制
│           └── 进度条
└── 状态栏
    ├── 状态消息
    └── 文件信息
```

### 事件处理系统

```mermaid
graph LR
    subgraph "事件源"
        MC[鼠标点击]
        KB[键盘输入]
        BT[按钮点击]
        LB[列表框选择]
    end
    
    subgraph "事件处理器"
        EH1[画布点击处理器]
        EH2[按键处理器]
        EH3[按钮点击处理器]
        EH4[列表框选择处理器]
    end
    
    subgraph "动作处理器"
        AP1[ROI管理]
        AP2[文件操作]
        AP3[显示更新]
        AP4[导出操作]
    end
    
    MC --> EH1
    KB --> EH2
    BT --> EH3
    LB --> EH4
    
    EH1 --> AP1
    EH2 --> AP1
    EH3 --> AP2
    EH3 --> AP4
    EH4 --> AP3
```

## 数据持久化

### ROI自动保存机制

```mermaid
graph TB
    subgraph "自动保存触发器"
        T1[加载新文件]
        T2[应用程序退出]
        T3[手动保存]
    end
    
    subgraph "数据收集"
        DC1[收集ROI坐标]
        DC2[提取光谱数据]
        DC3[收集元数据]
    end
    
    subgraph "CSV生成"
        CG1[创建数据帧]
        CG2[添加ROI索引]
        CG3[添加坐标]
        CG4[添加光谱数据]
        CG5[添加元数据]
    end
    
    subgraph "文件输出"
        FO1[生成文件名]
        FO2[写入CSV文件]
        FO3[错误处理]
    end
    
    T1 --> DC1
    T2 --> DC1
    T3 --> DC1
    
    DC1 --> DC2
    DC2 --> DC3
    
    DC3 --> CG1
    CG1 --> CG2
    CG2 --> CG3
    CG3 --> CG4
    CG4 --> CG5
    
    CG5 --> FO1
    FO1 --> FO2
    FO2 --> FO3
```

### 配置管理

```python
# 配置结构
config = {
    "logging": {
        "level": "INFO",
        "file": "hyperspectral_processor.log"
    },
    "processing": {
        "default_filter": "*.hdr",
        "auto_save_rois": True,
        "roi_default_size": 10
    },
    "ui": {
        "window_size": "1600x1000",
        "theme": "default"
    }
}
```

## 错误处理策略

### 错误类型和处理

1. **文件加载错误**:
   - 格式检测失败
   - 文件损坏
   - 缺少头文件

2. **处理错误**:
   - ROI坐标验证
   - 光谱提取失败
   - 内存分配问题

3. **UI错误**:
   - 画布渲染问题
   - 事件处理冲突
   - 状态同步问题

4. **导出错误**:
   - 文件权限问题
   - 磁盘空间问题
   - 格式兼容性问题

### 错误恢复

```mermaid
graph TB
    subgraph "错误检测"
        ED1[异常监控]
        ED2[输入验证]
        ED3[状态验证]
    end
    
    subgraph "错误处理"
        EH1[用户通知]
        EH2[状态回滚]
        EH3[资源清理]
    end
    
    subgraph "恢复动作"
        RA1[重试操作]
        RA2[跳过问题项]
        RA3[回退到默认值]
    end
    
    ED1 --> EH1
    ED2 --> EH2
    ED3 --> EH3
    
    EH1 --> RA1
    EH2 --> RA2
    EH3 --> RA3
```

## 性能考虑

### 内存管理
- **延迟加载**: 只加载必要的数据部分
- **ROI数据优化**: 只存储提取的光谱，而不是完整的图像数据
- **垃圾回收**: 正确清理临时对象
- **文件流处理**: 可能时对大文件进行分块处理

### UI响应性
- **异步操作**: 在后台线程中运行长时间任务
- **渐进式渲染**: 增量更新显示
- **事件防抖**: 防止过多的UI更新
- **缓存**: 缓存频繁访问的数据

## 扩展点

### 1. 文件格式支持
```python
class CustomDataLoader(DataLoader):
    def load_custom_format(self, file_path):
        # 实现自定义格式加载
        pass
```

### 2. 分析算法
```python
class AdvancedAnalyzer:
    def analyze_spectral_features(self, spectra):
        # 添加自定义分析算法
        pass
```

### 3. 导出格式
```python
class CustomExporter:
    def export_to_custom_format(self, data, file_path):
        # 实现自定义导出格式
        pass
```

### 4. UI主题
```python
class ThemeManager:
    def apply_dark_theme(self):
        # 实现主题切换
        pass
```

## 测试策略

### 单元测试
- DataLoader格式检测
- ROIProcessor坐标验证
- 导出服务文件生成

### 集成测试
- 文件加载和ROI处理管道
- UI事件处理和状态管理
- 自动保存/自动加载功能

### 性能测试
- 大文件加载性能
- 内存使用分析
- UI响应性指标

## 部署考虑

### 依赖项
```yaml
python: ">=3.8"
dependencies:
  - numpy>=1.21.0
  - matplotlib>=3.5.0
  - spectral>=0.22.0
  - pandas>=1.3.0
  - scipy>=1.7.0
  - tkinter  # 内置
```

### 平台支持
- **Windows**: 完全支持
- **macOS**: 完全支持
- **Linux**: 完全支持

### 分发选项
- PyPI包
- 独立可执行文件 (PyInstaller)
- Docker容器
- 源代码分发

## 未来增强

### 计划功能
1. **3D可视化**: 高光谱数据的体积渲染
2. **机器学习集成**: 自动化特征检测
3. **云集成**: 远程文件访问和处理
4. **插件系统**: 自定义算法的可扩展架构
5. **多语言支持**: 国际化
6. **高级导出**: 支持更多科学数据格式

### 技术债务
1. **重构UI组件**: 模块化复杂的UI元素
2. **改进错误消息**: 更用户友好的错误报告
3. **优化内存使用**: 更好地处理大型数据集
4. **增强测试**: 提高测试覆盖率
5. **文档**: 完整的API文档

此架构为专业的高光谱分析工具提供了坚实的基础，具有出色的可扩展性和可维护性特征。
