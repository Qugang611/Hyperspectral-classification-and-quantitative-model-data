# Unified Hyperspectral Viewer

A comprehensive Python application for processing and analyzing hyperspectral data with interactive ROI selection, spectral analysis, and batch processing capabilities in a unified single-page interface.

## Features

- **Unified Interface**: Single-page design with all functionality visible
- **Multi-format Support**: Load and process various hyperspectral file formats (ENVI, MATLAB, raw data files)
- **Interactive ROI Management**: Graphical interface for selecting and managing regions of interest
- **Real-time Spectral Analysis**: Live spectrum visualization with multiple ROI comparison
- **Batch Processing**: Process multiple files with folder import and file filtering
- **Enhanced Export**: Save images, spectra plots, and CSV data with intelligent default naming
- **Auto-save/Auto-load**: Automatic ROI data persistence between sessions
- **Enhanced Visualization**: ROI numbering, selection highlighting, and professional image output

## Installation

### Prerequisites

- Python 3.8 or higher
- pip package manager

### Install Dependencies

```bash
pip install -r requirements.txt
```

### Run the Application

```bash
python run_unified.py
```

## Quick Start

1. **Launch the application**: Run `python run_unified.py`
2. **Load a file**: Click "Load File" to open a hyperspectral file
3. **Create ROIs**: Click on the image to create regions of interest
4. **Analyze spectra**: View real-time spectral curves in the spectrum panel
5. **Save results**: Use the save buttons to export images, plots, and data

## Project Architecture

### System Overview

```mermaid
graph TB
    subgraph "Application Layer"
        UV[Unified Viewer]
        CM[Config Manager]
        LG[Logger]
    end
    
    subgraph "Core Processing Layer"
        DL[Data Loader]
        RP[ROI Processor]
    end
    
    subgraph "UI Layer"
        MF[Main Frame]
        IF[Image Frame]
        SF[Spectrum Frame]
        BF[Batch Frame]
    end
    
    subgraph "External Dependencies"
        TK[Tkinter]
        MPL[Matplotlib]
        NP[NumPy]
        SP[Spectral]
        PD[Pandas]
    end
    
    UV --> CM
    UV --> LG
    UV --> DL
    UV --> RP
    UV --> MF
    MF --> IF
    MF --> SF
    MF --> BF
    
    DL --> NP
    DL --> SP
    RP --> NP
    IF --> MPL
    SF --> MPL
    MF --> TK
```

### Class Diagram

```mermaid
classDiagram
    class UnifiedHyperspectralViewer {
        -current_hsi_data: ndarray
        -current_wavelengths: ndarray
        -current_file_path: str
        -roi_patches: list
        -roi_spectra: list
        -roi_colors: list
        -active_roi_index: int
        -roi_labels: list
        +__init__()
        +run()
        -_setup_ui()
        -_setup_event_bindings()
        -_load_file()
        -_add_roi()
        -_delete_roi()
        -_save_image()
        -_save_spectrum_fig()
        -_save_spectra()
    }
    
    class DataLoader {
        +load_file(file_path): tuple
        +check_and_add_byte_order(hdr_path)
    }
    
    class ROIProcessor {
        +extract_spectrum(hsi_data, coords): ndarray
    }
    
    class ConfigManager {
        +load_config()
        +save_config()
    }
    
    UnifiedHyperspectralViewer --> DataLoader
    UnifiedHyperspectralViewer --> ROIProcessor
    UnifiedHyperspectralViewer --> ConfigManager
```

### Sequence Diagram: File Loading and ROI Processing

```mermaid
sequenceDiagram
    participant User
    participant Viewer
    participant DataLoader
    participant ROIProcessor
    
    User->>Viewer: Load File
    Viewer->>DataLoader: load_file(file_path)
    DataLoader-->>Viewer: hsi_data, wavelengths
    Viewer->>Viewer: Clear existing ROIs
    Viewer->>Viewer: Try auto-load ROIs from CSV
    Viewer-->>User: Display image and spectra
    
    User->>Viewer: Click to create ROI
    Viewer->>ROIProcessor: extract_spectrum(coords)
    ROIProcessor-->>Viewer: spectrum_data
    Viewer->>Viewer: Update displays
    Viewer-->>User: Show ROI and spectrum
    
    User->>Viewer: Save Results
    Viewer->>Viewer: Export data to CSV/PNG
    Viewer-->>User: Confirmation message
```

## Key Components

### UnifiedHyperspectralViewer (`hyperspectral_processor/unified_viewer.py`)
Main application class that integrates all functionality in a single interface.

### DataLoader (`hyperspectral_processor/core/data_loader.py`)
Handles loading of various hyperspectral file formats with byte order detection.

### ROIProcessor (`hyperspectral_processor/core/roi_processor.py`)
Extracts spectral data from selected ROIs and manages coordinate processing.

### ConfigManager (`hyperspectral_processor/config/config_manager.py`)
Manages application configuration and settings persistence.

## File Structure

```
hyperspectral_processor/
├── __init__.py                 # Package initialization
├── unified_viewer.py          # Main unified viewer application
├── config/                    # Configuration management
│   ├── __init__.py
│   ├── config_manager.py      # Configuration manager
│   └── settings.py           # Application settings
├── core/                      # Core processing modules
│   ├── __init__.py
│   ├── data_loader.py        # Data loading and format handling
│   └── roi_processor.py      # ROI processing
├── utils/                     # Utility functions
│   ├── __init__.py
│   ├── logger.py             # Logging configuration
│   ├── file_utils.py         # File operations utilities
│   └── validation.py         # Data validation
└── run_unified.py            # Application entry point
```

## Usage Examples

### Basic Operation

```python
# Run the unified viewer
from hyperspectral_processor.unified_viewer import main
main()
```

### Programmatic ROI Processing

```python
from hyperspectral_processor.core.data_loader import DataLoader
from hyperspectral_processor.core.roi_processor import ROIProcessor

# Load data
loader = DataLoader()
hsi_data, wavelengths, metadata = loader.load_file("sample.hdr")

# Process ROIs
processor = ROIProcessor()
roi_coords = [(100, 100, 110, 110), (200, 200, 210, 210)]
spectra = [processor.extract_spectrum(hsi_data, coords) for coords in roi_coords]
```

## Supported File Formats

- **ENVI Files**: `.hdr` header files with associated data files
- **MATLAB Files**: `.mat` files containing hyperspectral data
- **Raw Data Files**: `.dat`, `.img`, `.raw` with appropriate headers
- **Common Image Formats**: Limited spectral support

## Configuration

The application uses `config.ini` for persistent settings:

```ini
[logging]
level = INFO
file = hyperspectral_processor.log

[processing]
default_filter = *.hdr
auto_save_rois = true
```

## Enhanced Features

### ROI Management
- **Numbered ROIs**: Each ROI displays its index number
- **Selection Highlighting**: Active ROIs have thicker borders
- **Keyboard Navigation**: Arrow keys to move selected ROI
- **Auto-persistence**: ROIs automatically saved/loaded with files

### Export Capabilities
- **High-quality Images**: 300 DPI PNG/JPEG/PDF/SVG output
- **Intelligent Naming**: Automatic filename generation
- **CSV Data Export**: Comprehensive spectral data with metadata
- **Spectrum Plots**: Professional-quality spectral charts

### Batch Processing
- **Folder Import**: Add entire folders with file filtering
- **File Navigation**: Previous/Next file navigation
- **Progress Tracking**: Visual progress indicators

## Dependencies

- **Python 3.8+**: Core language
- **Tkinter**: GUI framework
- **Matplotlib**: Plotting and visualization
- **NumPy**: Numerical computations
- **Spectral**: Hyperspectral data processing
- **Pandas**: Data export and manipulation
- **SciPy**: Scientific computing

## Contributing

1. Fork the repository
2. Create a feature branch (`git checkout -b feature/amazing-feature`)
3. Commit your changes (`git commit -m 'Add amazing feature'`)
4. Push to the branch (`git push origin feature/amazing-feature`)
5. Open a Pull Request

## License

This project is licensed under the MIT License - see the LICENSE file for details.

## Support

For issues and questions, please check the documentation or open an issue on the repository.
